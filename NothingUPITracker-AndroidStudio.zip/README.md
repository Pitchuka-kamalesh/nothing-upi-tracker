
## Imported transaction cleanup
- Activity screen includes source filters for All, SMS, Notifications and CSV.
- Transactions can be selected individually or with Select all, then deleted in bulk.
- Each visible transaction also has a Delete action.
- Deletion removes the transaction from DotLedger's Room database and refreshes the home-screen widget; it does not delete the original SMS from the phone inbox.
- SMS inbox permissions and automatic SMS receiver have been removed from the Google Play release. Users manually select an SMS text export or bank CSV through Android’s document picker. The app reads only the file the user selects; it does not scan the device inbox.

## Saved bank balances (v4)

The Banks tab now starts with these four selected banks:
- HDFC Bank
- Punjab National Bank (PNB)
- Bank of Baroda
- Federal Bank

Enter a current or opening balance in rupees, optionally add the last four account digits, and tap **Save balance**. Balances are stored locally in the `bank_accounts` Room table with a saved timestamp and are kept separate from UPI transaction totals. Removing a bank hides it from the saved bank list; its transaction history is retained. The Room 3-to-4 migration creates the new table without deleting existing transactions.

## Payment notes and refreshed interface (v5)
- Every transaction now supports a private editable note (up to 500 characters) from Activity and expanded Category transaction lists.
- Notes are stored in the local Room `transactions.comment` column and survive app restarts.
- Transaction search includes notes, so you can search for text you wrote.
- CSV exports and JSON backups include the note field; JSON restore reads it when present.
- Room migration 4-to-5 adds the comment column with an empty default, preserving existing transactions.
- Updated the DotLedger header, transaction cards, metric cards and feature panels with a subtle dark-glass gradient and restrained red accent styling.

The app remains local-first. Notes are stored on the device and are not sent to an AI service.


## Real-time UPI notification capture

The Android manifest declares `PaymentNotificationListener` with the required `BIND_NOTIFICATION_LISTENER_SERVICE` permission. Android does not grant notification access automatically: open **More → Enable notification access**, then enable DotLedger in Android's Notification access settings. The More screen displays whether access is enabled.

Notifications from Google Pay, PhonePe, Paytm and Super.money are parsed when the app package is recognized and the notification text contains a readable amount plus a credit/debit indicator. Captured records are labelled `NOTIFICATION: <app>` so the Activity source filter can identify them. Notification access cannot read notifications that Android or the payment app hides, and the parser cannot guarantee every wording variant; verify imported transactions against your bank statement.


## Payment-app notification capture and cross-source duplicate prevention

- The notification listener now examines notifications from installed apps, not only a fixed package allowlist. Known payment apps receive friendly source names (Google Pay, PhonePe, Paytm, Super.money, BHIM, Amazon Pay, CRED, MobiKwik, Freecharge, Airtel Thanks, WhatsApp Pay, Navi, PayZapp and supported bank apps); other apps use their installed app label.
- A notification is saved only when the payment parser finds a valid amount and a credit/debit transaction indicator. Ordinary notifications are ignored.
- Notification timestamps use Android's notification post time. SMS receiver and SMS history import retain the SMS timestamp.
- Import deduplication uses normalized UPI reference when available, plus a cross-source fallback for SMS-vs-notification events within three minutes. The fallback checks amount, direction, bank/account and merchant evidence.
- A process-wide import mutex prevents the SMS receiver and notification listener from racing each other while checking and inserting the same payment.
- Notification access must be enabled manually in Android Settings. Capturing notifications from any app is possible only while that user-granted access is enabled.

Privacy: notification text is inspected locally by the app. Only messages recognized as payment transactions are saved to the local Room database; unrelated notification text is not persisted.

## October 2026 SMS false-positive parser fix

- Payment amount is now extracted from the amount immediately associated with an explicit credited/debited/received/paid transaction verb.
- Later `Bal INR ...` values are not treated as transaction amounts.
- Generic phrases such as `payment successful` or a balance-only message no longer create a transaction.
- Requires account/payment-rail/reference context before importing.
- Verified parser examples for PNB `credited for INR 1.00 ... Bal INR 4.84` and `debited INR 1.00 ... Bal INR 3.84`; both parse as ₹1.00 with correct direction. Balance-only and promotional examples are ignored.


## Google Play internal-testing release preparation (v1.2)

- Removed `READ_SMS`, `RECEIVE_SMS`, the SMS broadcast receiver and direct SMS inbox querying. SMS/statement import is user-initiated via Android's Storage Access Framework document picker.
- CSV and text import remain available. The app only opens the file explicitly selected by the user.
- Notification access remains optional and user-granted. The listener now processes only recognized payment/banking package identifiers and ignores unrelated app notifications. The More screen discloses what notification data is inspected and that recognized payment records are stored locally.
- App target/compile SDK raised to Android 16 (API 36), required for new Play submissions from 31 August 2026.
- CI always builds a debug APK. A signed Play AAB is built only when the release keystore GitHub Actions secrets are configured.

### Configure Play signing in GitHub

Create and securely back up your own upload keystore. Add these GitHub repository Actions secrets: `ANDROID_KEYSTORE_BASE64` (base64-encoded JKS), `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, and `ANDROID_KEY_PASSWORD`. Never commit the keystore or passwords. After configuring secrets, run Actions; download `DotLedger-play-release-aab` and upload it to Play Console → Testing → Internal testing. Enrol your tester Google accounts and use the Play opt-in link.

### Before submission

1. Replace the example privacy-policy URL in your Play listing with a real public policy that accurately describes local storage, manual file imports and optional notification access.
2. Complete Play Console Data safety, App content, ads declaration (if applicable), and notification-access disclosures accurately.
3. Review the notification listener policy eligibility and user-facing prominent disclosure/consent requirements before enabling it in the Play build.
4. Test on physical devices: manual text/CSV import, duplicate matching, comments, bank balances, backup/export, PIN lock, notification access opt-in, and uninstall/reinstall data behaviour.
5. Confirm the package name and signing key are permanent before the first Play upload.

This source package is prepared for internal testing; Google Play approval and Play Protect status cannot be guaranteed by source changes alone.


## Privacy policy publication checklist

Before Play internal testing, publish a policy page under a URL you control. It must identify the developer/operator and contact email, describe local-only transaction storage, manual file imports, optional notification-listener processing, retention/deletion, backup/export behaviour, children's privacy, security limitations and how users contact the developer. Do not publish this template unchanged until the placeholders and statements have been verified against the final app build.

### Generate your own upload keystore (run once on a trusted computer)

```bash
keytool -genkeypair -v -keystore dotledger-upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias dotledger-upload
base64 -w 0 dotledger-upload.jks > dotledger-upload.jks.base64
```

Keep the original `.jks` and passwords in a secure offline backup. Store the base64 contents and passwords only in GitHub Actions secrets. Never commit either file. For Play App Signing, Google manages the app-signing key after enrolment; this keystore is the upload key.
