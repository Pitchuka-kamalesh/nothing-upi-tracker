# Nothing UPI Tracker – patched source

Changes in this patch:
- Added Super.money notification package recognition (`supermoney` / `super.money`).
- Notification listener now combines title, text, big text, subtext, ticker and text lines.
- Fixed over-escaped payment parser regular expressions that prevented amount/reference extraction.
- Added incoming SMS broadcast receiver and RECEIVE_SMS permission; app prompts for this permission.
- Added Compose status/navigation bar insets so the top header is not drawn underneath the status bar.
- Existing monthly spending card remains and calculates current-month expenses from the local Room transaction stream.

## Build
Open this folder in Android Studio and sync Gradle. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Device setup
1. Install the debug APK.
2. Open UPI Tracker and grant SMS permission when prompted.
3. Enable UPI Tracker under Settings > Apps > Special app access > Notification access.
4. Keep notifications enabled for GPay, PhonePe, Paytm and Super.money.

## Important
- The app captures only notifications actually posted by those apps. Android may hide or redact notification content depending on device/app privacy settings.
- SMS capture requires the runtime RECEIVE_SMS permission. Google Play distribution has additional SMS permission policy restrictions; private sideload/testing is different.
- CSV importer still expects the existing starter column layout documented in Importers.kt.
- The source archive does not include Gradle wrapper files, so open in Android Studio with a compatible installed Gradle/Android Gradle Plugin setup.


## Dashboard and widget improvements (follow-up)
- Dashboard now switches between Monthly and Yearly expense totals.
- Each transaction has a category picker so the user can manually classify it.
- Reset categories sets all transactions to `Other`; the user can reassign them individually.
- After every newly imported transaction, the Glance home-screen widget is explicitly refreshed.
- Monthly widget total remains based on the current calendar month.


## Category-wise spending UI
- Added emoji illustrations for Savings, Vegetables, Groceries, Snacks, Food & Dining, Shopping, Travel, Transport, Fuel, Bills, Healthcare, Entertainment, Rent, Education, Transfer, Cash, Personal and Other.
- Dashboard shows category-wise expense totals for the selected Monthly or Yearly period, with proportional bars.
- Each transaction retains its manual category picker.


### Import old SMS history
Open the app and tap **Allow SMS** to grant both SMS receive and read permissions. Tap the button again (it changes to **Import old SMS**) to scan the existing inbox and import payment-related messages. Repeated scans skip already imported transactions. New incoming SMS continues to be captured by the receiver. Android will display a sensitive SMS permission prompt; grant it only if you trust this locally installed app.

## Date-wise reconciliation and bank dashboard update

- Existing inbox SMS are parsed with the original SMS timestamp, not the import time. This is important for correct daily/monthly totals.
- Credits, deposits and received UPI payments are classified as `INCOME`; debits, withdrawals and sent payments are classified as `EXPENSE`.
- Home shows today's credit/deposit total, today's debit/spend total, net flow, period totals and daily grouped totals.
- Banks tab groups transactions by bank names detected in the SMS body and shows money-in/money-out totals and masked account suffixes when available. Messages without a detectable bank are grouped as `Unknown bank`; the app cannot infer the bank reliably if the SMS does not name it.
- Categories tab has expandable category rows and a reset action. Reset sets every transaction category to `Other`; it does not delete transactions.
- Bottom navigation: Home, Activity, Banks, Categories.
- Room database migration 1→2 adds bank name and account suffix fields without deleting existing transactions.

Note: Bank identification is text-based and may need additional aliases for the exact sender/message formats used by your bank. Reconcile totals against bank statements before relying on them for accounting.


## Next release: Nothing OS dark finance tools
- Added a fifth **More** navigation destination while retaining Home, Activity, Banks and Categories.
- Added transaction search across merchant, bank, category, source, reference, account suffix and amount.
- Added persistent per-category monthly budgets in Room, with progress bars and 80% / exceeded indicators. Database migration 2→3 creates the budgets table and retains transactions.
- Added monthly on-device analytics for money-in, money-out, net flow and top spending category. These are local rule-based insights, not a connected generative-AI service.
- Added recurring-payment candidates based on repeated merchant names and approximate weekly / fortnightly / monthly gaps. Candidates require manual review.
- Added reconciliation candidates for same-date, same-amount credits and debits across different identified banks. These are not confirmed own-account transfers and are not automatically removed from totals.
- Bank screen now includes source-app counts alongside bank/account money-in and money-out totals.
- Added CSV report export and JSON transaction backup using Android's document picker. JSON restore/import is not included yet.
- Added a local 4–6 digit PIN lock. The PIN is stored as a SHA-256 hash in app-private preferences. Biometric unlock is not included yet.
- Preserved the existing Glance home-screen expense widget; add it from the launcher Widgets panel.
- Preserved old-SMS import, real-time SMS/notification capture, category controls, and the GitHub Actions APK workflow.

### Important limitations
- Transaction matching, bank-name extraction and recurring-payment detection are heuristic. Confirm results against official bank statements.
- Local insights are calculated on-device and do not call an AI model.
- JSON backup currently exports transactions and their fields; a restore flow is not yet implemented.
- PIN lock is PIN-only in this release; biometric unlock is not implemented.
- The project has no Gradle wrapper. Source was updated, but a Gradle build/device test was not run in this environment. Run the existing GitHub Actions workflow to validate compilation and APK output.


## App name and launcher icon

Recommended app name: **DotLedger** (UPI & Expense Tracker). The launcher icon uses a minimal dot-grid motif with a red upward transaction line, inspired by a monochrome/dark-glass visual direction. The app is independently branded and is not an official Nothing product.
