
## Imported transaction cleanup
- Activity screen includes source filters for All, SMS, Notifications and CSV.
- Transactions can be selected individually or with Select all, then deleted in bulk.
- Each visible transaction also has a Delete action.
- Deletion removes the transaction from DotLedger's Room database and refreshes the home-screen widget; it does not delete the original SMS from the phone inbox.
- The SMS history importer continues to import only messages recognized as payment transactions. Non-payment SMS are skipped and are not stored in the app.

## Saved bank balances (v4)

The Banks tab now starts with these four selected banks:
- HDFC Bank
- Punjab National Bank (PNB)
- Bank of Baroda
- Federal Bank

Enter a current or opening balance in rupees, optionally add the last four account digits, and tap **Save balance**. Balances are stored locally in the `bank_accounts` Room table with a saved timestamp and are kept separate from UPI transaction totals. Removing a bank hides it from the saved bank list; its transaction history is retained. The Room 3-to-4 migration creates the new table without deleting existing transactions.

## Payment notes and refreshed interface (v5)
- Every transaction now supports a private editable note (up to 500 characters) from Activity and expanded Category transaction lists.
- Notes are stored in the local Room `transactions.comment` column and survive app restarts.
- Transaction search includes notes, so you can search for text you wrote.
- CSV exports and JSON backups include the note field; JSON restore reads it when present.
- Room migration 4-to-5 adds the comment column with an empty default, preserving existing transactions.
- Updated the DotLedger header, transaction cards, metric cards and feature panels with a subtle dark-glass gradient and restrained red accent styling.

The app remains local-first. Notes are stored on the device and are not sent to an AI service.
