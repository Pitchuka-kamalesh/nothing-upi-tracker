# Nothing UPI Tracker — Android Studio source

## Included
- Kotlin + Jetpack Compose dashboard with Nothing-inspired styling
- Room local database
- Notification listener for Google Pay, PhonePe and Paytm package-name candidates
- User-selected text export import for SMS
- Starter CSV import adapter
- Merchant keyword categorization
- Native Glance home-screen widget

## Build
1. Install Android Studio and JDK 17.
2. Install Android SDK Platform 35.
3. Open this folder in Android Studio and sync Gradle.
4. Run on your Nothing Phone (4a) Pro.
5. Add UPI Tracker from the launcher's widget picker.

## Enable notification capture
Open the app > Enable alerts > enable UPI Tracker under Android Notification access.
This is opt-in. Android delivers future notifications only while access is granted and the service is active.

## Imports
- SMS import: choose a text file exported from your SMS app. No READ_SMS permission is requested.
- CSV import: starter parser expects description in column 3, amount in column 4, and debit/credit direction in column 5 (zero-based). Adapt the column mapping and date parsing to your bank's actual CSV format.

## Important limitations
- Notification package identifiers and wording differ across app versions and devices. Verify them on your phone with redacted sample notifications.
- The parser deliberately skips notifications without an explicit currency amount and debit/credit wording.
- CSV and SMS imports are starter adapters, not universal bank statement parsers.
- Duplicate detection uses UPI reference where present; otherwise a content-based key.
- This is a starter project. It does not yet include transaction editing/deletion, budget configuration, or complete date parsing for imported statements.
- No UPI PIN, OTP, bank password, bank login, or payment initiation is used.
- The Glance widget is a native Android widget, not a Nothing Playground Essential App.
- Verify all captured and imported transactions against your bank statement before relying on totals.
