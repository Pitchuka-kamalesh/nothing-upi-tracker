
## Imported transaction cleanup
- Activity screen includes source filters for All, SMS, Notifications and CSV.
- Transactions can be selected individually or with Select all, then deleted in bulk.
- Each visible transaction also has a Delete action.
- Deletion removes the transaction from DotLedger's Room database and refreshes the home-screen widget; it does not delete the original SMS from the phone inbox.
- The SMS history importer continues to import only messages recognized as payment transactions. Non-payment SMS are skipped and are not stored in the app.

## Saved bank balances (v4)

The Banks tab now starts with these four selected banks:
- HDFC Bank
- Punjab National Bank (PNB)
- Bank of Baroda
- Federal Bank

Enter a current or opening balance in rupees, optionally add the last four account digits, and tap **Save balance**. Balances are stored locally in the `bank_accounts` Room table with a saved timestamp and are kept separate from UPI transaction totals. Removing a bank hides it from the saved bank list; its transaction history is retained. The Room 3-to-4 migration creates the new table without deleting existing transactions.

## Payment notes and refreshed interface (v5)
- Every transaction now supports a private editable note (up to 500 characters) from Activity and expanded Category transaction lists.
- Notes are stored in the local Room `transactions.comment` column and survive app restarts.
- Transaction search includes notes, so you can search for text you wrote.
- CSV exports and JSON backups include the note field; JSON restore reads it when present.
- Room migration 4-to-5 adds the comment column with an empty default, preserving existing transactions.
- Updated the DotLedger header, transaction cards, metric cards and feature panels with a subtle dark-glass gradient and restrained red accent styling.

The app remains local-first. Notes are stored on the device and are not sent to an AI service.


## Real-time UPI notification capture

The Android manifest declares `PaymentNotificationListener` with the required `BIND_NOTIFICATION_LISTENER_SERVICE` permission. Android does not grant notification access automatically: open **More → Enable notification access**, then enable DotLedger in Android's Notification access settings. The More screen displays whether access is enabled.

Notifications from Google Pay, PhonePe, Paytm and Super.money are parsed when the app package is recognized and the notification text contains a readable amount plus a credit/debit indicator. Captured records are labelled `NOTIFICATION: <app>` so the Activity source filter can identify them. Notification access cannot read notifications that Android or the payment app hides, and the parser cannot guarantee every wording variant; verify imported transactions against your bank statement.


## Payment-app notification capture and cross-source duplicate prevention

- The notification listener now examines notifications from installed apps, not only a fixed package allowlist. Known payment apps receive friendly source names (Google Pay, PhonePe, Paytm, Super.money, BHIM, Amazon Pay, CRED, MobiKwik, Freecharge, Airtel Thanks, WhatsApp Pay, Navi, PayZapp and supported bank apps); other apps use their installed app label.
- A notification is saved only when the payment parser finds a valid amount and a credit/debit transaction indicator. Ordinary notifications are ignored.
- Notification timestamps use Android's notification post time. SMS receiver and SMS history import retain the SMS timestamp.
- Import deduplication uses normalized UPI reference when available, plus a cross-source fallback for SMS-vs-notification events within three minutes. The fallback checks amount, direction, bank/account and merchant evidence.
- A process-wide import mutex prevents the SMS receiver and notification listener from racing each other while checking and inserting the same payment.
- Notification access must be enabled manually in Android Settings. Capturing notifications from any app is possible only while that user-granted access is enabled.

Privacy: notification text is inspected locally by the app. Only messages recognized as payment transactions are saved to the local Room database; unrelated notification text is not persisted.
