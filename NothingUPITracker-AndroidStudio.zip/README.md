# Nothing UPI Tracker – patched source

Changes in this patch:
- Added Super.money notification package recognition (`supermoney` / `super.money`).
- Notification listener now combines title, text, big text, subtext, ticker and text lines.
- Fixed over-escaped payment parser regular expressions that prevented amount/reference extraction.
- Added incoming SMS broadcast receiver and RECEIVE_SMS permission; app prompts for this permission.
- Added Compose status/navigation bar insets so the top header is not drawn underneath the status bar.
- Existing monthly spending card remains and calculates current-month expenses from the local Room transaction stream.

## Build
Open this folder in Android Studio and sync Gradle. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Device setup
1. Install the debug APK.
2. Open UPI Tracker and grant SMS permission when prompted.
3. Enable UPI Tracker under Settings > Apps > Special app access > Notification access.
4. Keep notifications enabled for GPay, PhonePe, Paytm and Super.money.

## Important
- The app captures only notifications actually posted by those apps. Android may hide or redact notification content depending on device/app privacy settings.
- SMS capture requires the runtime RECEIVE_SMS permission. Google Play distribution has additional SMS permission policy restrictions; private sideload/testing is different.
- CSV importer still expects the existing starter column layout documented in Importers.kt.
- The source archive does not include Gradle wrapper files, so open in Android Studio with a compatible installed Gradle/Android Gradle Plugin setup.


## Dashboard and widget improvements (follow-up)
- Dashboard now switches between Monthly and Yearly expense totals.
- Each transaction has a category picker so the user can manually classify it.
- Reset categories sets all transactions to `Other`; the user can reassign them individually.
- After every newly imported transaction, the Glance home-screen widget is explicitly refreshed.
- Monthly widget total remains based on the current calendar month.


## Category-wise spending UI
- Added emoji illustrations for Savings, Vegetables, Groceries, Snacks, Food & Dining, Shopping, Travel, Transport, Fuel, Bills, Healthcare, Entertainment, Rent, Education, Transfer, Cash, Personal and Other.
- Dashboard shows category-wise expense totals for the selected Monthly or Yearly period, with proportional bars.
- Each transaction retains its manual category picker.
