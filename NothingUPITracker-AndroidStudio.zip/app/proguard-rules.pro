# Room uses generated implementations; retain runtime annotations and database schema metadata.
-keepattributes *Annotation*
-keep class androidx.room.** { *; }
-dontwarn kotlinx.coroutines.**
