package com.kamal.nothingupi.capture

import android.content.Context
import android.net.Uri
import com.kamal.nothingupi.data.PaymentParser
import com.kamal.nothingupi.data.TransactionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Importers {
    suspend fun importText(context: Context, uri: Uri, source: String): Int = withContext(Dispatchers.IO) {
        var imported = 0
        val repo = TransactionRepository(context)
        context.contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { lines ->
            lines.forEach { line ->
                val parsed = PaymentParser.parse(line, source)
                if (parsed != null && repo.import(parsed)) imported++
            }
        }
        imported
    }

    // Starter CSV adapter. Customize column mapping for your bank's statement.
    // Expected: description in column 3, amount in column 4, direction in column 5.
    suspend fun importCsv(context: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        var imported = 0
        val repo = TransactionRepository(context)
        context.contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { lines ->
            lines.drop(1).forEach { line ->
                val columns = line.split(',', limit = 8).map { it.trim().trim('"') }
                if (columns.size >= 5) {
                    val parsed = PaymentParser.parse(
                        "${columns[4]} ${columns[2]} INR ${columns[3]}", "CSV"
                    )
                    if (parsed != null && repo.import(parsed)) imported++
                }
            }
        }
        imported
    }
}
