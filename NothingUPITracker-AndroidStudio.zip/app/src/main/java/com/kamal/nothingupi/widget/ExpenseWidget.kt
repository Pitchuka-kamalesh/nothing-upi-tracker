package com.kamal.nothingupi.widget

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.appwidget.*
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider
import com.kamal.nothingupi.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

class ExpenseWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: android.content.Context, id: GlanceId) {
        val totals = withContext(Dispatchers.IO) {
            val dao = AppDatabase.get(context).transactions()
            val now = Calendar.getInstance()
            val dayStart = (now.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val monthStart = (now.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            dao.expenseTotal(dayStart, System.currentTimeMillis() + 1) to
                dao.expenseTotal(monthStart, System.currentTimeMillis() + 1)
        }
        provideContent {
            Column(
                GlanceModifier.fillMaxSize().background(ColorProvider(Color(0xFF080808))).padding(14.dp),
                verticalAlignment = Alignment.Vertical.CenterVertically
            ) {
                Text("UPI / TRACKER", style = TextStyle(color = ColorProvider(Color.White), fontSize = 13.sp))
                Spacer(GlanceModifier.height(7.dp))
                Text("TODAY", style = TextStyle(color = ColorProvider(Color.LightGray), fontSize = 10.sp))
                Text("₹${"%.2f".format(totals.first / 100.0)}",
                    style = TextStyle(color = ColorProvider(Color.White), fontSize = 23.sp))
                Spacer(GlanceModifier.height(5.dp))
                Text("MONTH  ₹${"%.2f".format(totals.second / 100.0)}",
                    style = TextStyle(color = ColorProvider(Color(0xFFE60012)), fontSize = 12.sp))
            }
        }
    }
}

class ExpenseWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ExpenseWidget()
}
