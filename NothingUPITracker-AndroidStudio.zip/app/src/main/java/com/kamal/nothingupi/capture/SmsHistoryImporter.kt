package com.kamal.nothingupi.capture

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Telephony
import androidx.core.content.ContextCompat
import com.kamal.nothingupi.data.PaymentParser
import com.kamal.nothingupi.data.TransactionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Imports payment-related messages already present in the device SMS inbox. */
object SmsHistoryImporter {
    suspend fun importInbox(context: Context): Int = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            throw SecurityException("SMS read permission was not granted")
        }
        var imported = 0
        val repo = TransactionRepository(context)
        val projection = arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE)
        context.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            projection,
            null,
            null,
            "${Telephony.Sms.DATE} ASC"
        )?.use { cursor ->
            val addressIndex = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
            val bodyIndex = cursor.getColumnIndex(Telephony.Sms.BODY)
            val dateIndex = cursor.getColumnIndex(Telephony.Sms.DATE)
            while (cursor.moveToNext()) {
                val address = if (addressIndex >= 0) cursor.getString(addressIndex).orEmpty() else ""
                val body = if (bodyIndex >= 0) cursor.getString(bodyIndex).orEmpty() else ""
                val date = if (dateIndex >= 0) cursor.getLong(dateIndex) else System.currentTimeMillis()
                val parsed = PaymentParser.parse("$address $body", "SMS HISTORY", date) ?: continue
                if (repo.import(parsed.copy(timestamp = date))) imported++
            }
        }
        imported
    }
}
