package com.kamal.nothingupi.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountPaise: Long,
    val type: String,
    val merchant: String,
    val category: String,
    val source: String,
    val reference: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val importKey: String = "",
    val bankName: String = "Unknown bank",
    val accountSuffix: String = "",
    val comment: String = ""
)
