package com.kamal.nothingupi.capture

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.kamal.nothingupi.data.PaymentParser
import com.kamal.nothingupi.data.TransactionRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class IncomingSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val pending = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                Telephony.Sms.Intents.getMessagesFromIntent(intent).forEach { message ->
                    val body = message.messageBody ?: return@forEach
                    val address = message.originatingAddress.orEmpty()
                    val text = "$address $body"
                    val parsed = PaymentParser.parse(text, "SMS")?.copy(timestamp = message.timestampMillis) ?: return@forEach
                    TransactionRepository(appContext).import(parsed)
                }
            } catch (t: Throwable) {
                Log.e("UPITrackerSms", "SMS processing failed", t)
            } finally {
                pending.finish()
            }
        }
    }
}
