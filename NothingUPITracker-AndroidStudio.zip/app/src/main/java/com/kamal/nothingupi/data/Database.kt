package com.kamal.nothingupi.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

@Entity(tableName = "budgets", primaryKeys = ["category"])
data class BudgetEntity(val category: String, val monthlyLimitPaise: Long, val updatedAt: Long = System.currentTimeMillis())

@Entity(tableName = "bank_accounts", primaryKeys = ["bankName"])
data class BankAccountEntity(
    val bankName: String,
    val balancePaise: Long = 0L,
    val balanceType: String = "CURRENT",
    val updatedAt: Long = 0L,
    val accountSuffix: String = "",
    val isSelected: Boolean = true
)

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE importKey = :key LIMIT 1")
    suspend fun findByKey(key: String): Transaction?

    // Cross-source duplicate candidates: SMS and app notifications often arrive a little apart.
    @Query("SELECT * FROM transactions WHERE amountPaise = :amountPaise AND type = :type AND timestamp BETWEEN :fromTime AND :toTime ORDER BY timestamp DESC")
    suspend fun findDuplicateCandidates(amountPaise: Long, type: String, fromTime: Long, toTime: Long): List<Transaction>

    @Insert
    suspend fun insert(item: Transaction): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(item: Transaction): Long

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM transactions WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("UPDATE transactions SET category = :category WHERE id = :id")
    suspend fun updateCategory(id: Long, category: String)

    @Query("UPDATE transactions SET comment = :comment WHERE id = :id")
    suspend fun updateComment(id: Long, comment: String)

    @Query("UPDATE transactions SET category = 'Other'")
    suspend fun resetCategories()

    @Query("SELECT COALESCE(SUM(amountPaise),0) FROM transactions WHERE type='EXPENSE' AND timestamp >= :start AND timestamp < :end")
    suspend fun expenseTotal(start: Long, end: Long): Long

    @Query("SELECT * FROM budgets ORDER BY category")
    fun observeBudgets(): Flow<List<BudgetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveBudget(item: BudgetEntity)

    @Query("DELETE FROM budgets WHERE category = :category")
    suspend fun deleteBudget(category: String)

    @Query("SELECT * FROM bank_accounts WHERE isSelected = 1 ORDER BY bankName")
    fun observeBankAccounts(): Flow<List<BankAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveBankAccount(item: BankAccountEntity)

    @Query("UPDATE bank_accounts SET isSelected = 0 WHERE bankName = :bankName")
    suspend fun hideBankAccount(bankName: String)

    @Query("SELECT COUNT(*) FROM bank_accounts")
    suspend fun bankAccountCount(): Int
}

@Database(entities = [Transaction::class, BudgetEntity::class, BankAccountEntity::class], version = 5, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactions(): TransactionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE transactions ADD COLUMN bankName TEXT NOT NULL DEFAULT 'Unknown bank'")
                db.execSQL("ALTER TABLE transactions ADD COLUMN accountSuffix TEXT NOT NULL DEFAULT ''")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS budgets (category TEXT NOT NULL, monthlyLimitPaise INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(category))")
            }
        }
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS bank_accounts (bankName TEXT NOT NULL, balancePaise INTEGER NOT NULL, balanceType TEXT NOT NULL, updatedAt INTEGER NOT NULL, accountSuffix TEXT NOT NULL, isSelected INTEGER NOT NULL, PRIMARY KEY(bankName))")
            }
        }
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE transactions ADD COLUMN comment TEXT NOT NULL DEFAULT ''")
            }
        }
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "nothing_upi.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5).build().also { INSTANCE = it }
        }
    }
}

class TransactionRepository(context: Context) {
    private val appContext = context.applicationContext
    private val importMutex = companionImportMutex
    private val dao = AppDatabase.get(appContext).transactions()
    fun observe() = dao.observeAll()
    fun observeBudgets() = dao.observeBudgets()
    suspend fun saveBudget(category: String, amountPaise: Long) = dao.saveBudget(BudgetEntity(category, amountPaise))
    suspend fun deleteBudget(category: String) = dao.deleteBudget(category)
    fun observeBankAccounts() = dao.observeBankAccounts()
    suspend fun saveBankBalance(bankName: String, balancePaise: Long, balanceType: String, accountSuffix: String = "") =
        dao.saveBankAccount(BankAccountEntity(bankName, balancePaise, balanceType, System.currentTimeMillis(), accountSuffix, true))
    suspend fun deleteBankAccount(bankName: String) = dao.hideBankAccount(bankName)
    suspend fun seedDefaultBankAccounts() {
        if (dao.bankAccountCount() == 0) {
            listOf("HDFC Bank", "Punjab National Bank (PNB)", "Bank of Baroda", "Federal Bank").forEach {
                dao.saveBankAccount(BankAccountEntity(bankName = it, updatedAt = 0L))
            }
        }
    }

    suspend fun add(item: Transaction): Long {
        val id = dao.insert(item)
        refreshWidget()
        return id
    }

    suspend fun setCategory(id: Long, category: String) = dao.updateCategory(id, category)
    suspend fun setComment(id: Long, comment: String) = dao.updateComment(id, comment.trim().take(500))

    suspend fun deleteTransaction(id: Long) {
        dao.deleteById(id)
        refreshWidget()
    }

    suspend fun deleteTransactions(ids: List<Long>) {
        if (ids.isNotEmpty()) dao.deleteByIds(ids)
        refreshWidget()
    }

    suspend fun resetCategories() {
        dao.resetCategories()
        refreshWidget()
    }

    private suspend fun refreshWidget() {
        runCatching {
            androidx.glance.appwidget.GlanceAppWidgetManager(appContext)
                .getGlanceIds(com.kamal.nothingupi.widget.ExpenseWidget::class.java)
                .forEach { com.kamal.nothingupi.widget.ExpenseWidget().update(appContext, it) }
        }
    }

    suspend fun restoreBackup(root: org.json.JSONObject): Int {
        require(root.optString("format").startsWith("nothing-upi-backup")) { "Unsupported backup format" }
        val array = root.optJSONArray("transactions") ?: org.json.JSONArray()
        var restored = 0
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val timestampRaw = obj.optLong("timestamp", System.currentTimeMillis())
            val timestamp = if (timestampRaw in 1..99_999_999_999L) timestampRaw * 1000L else timestampRaw
            val tx = Transaction(
                amountPaise = obj.optLong("amountPaise"),
                type = obj.optString("type", "EXPENSE"),
                merchant = obj.optString("merchant", "Imported transaction"),
                category = obj.optString("category", "Other"),
                source = obj.optString("source", "RESTORE"),
                reference = obj.optString("reference", ""),
                timestamp = timestamp,
                importKey = obj.optString("importKey", ""),
                bankName = obj.optString("bankName", "Unknown bank"),
                accountSuffix = obj.optString("accountSuffix", ""),
                comment = obj.optString("comment", "")
            )
            if (tx.amountPaise <= 0 || tx.type !in listOf("INCOME", "EXPENSE")) continue
            val key = tx.importKey.ifBlank { "RESTORE:${tx.timestamp}:${tx.amountPaise}:${tx.type}:${tx.merchant}" }
            if (dao.findByKey(key) == null) {
                dao.insertIgnore(tx.copy(id = 0, importKey = key))
                restored++
            }
        }
        val bankArray = root.optJSONArray("banks") ?: org.json.JSONArray()
        for (i in 0 until bankArray.length()) {
            val b = bankArray.optJSONObject(i) ?: continue
            val name = b.optString("bankName").trim()
            if (name.isNotEmpty()) dao.saveBankAccount(BankAccountEntity(
                bankName = name, balancePaise = b.optLong("balancePaise"),
                balanceType = b.optString("balanceType", "CURRENT"),
                updatedAt = b.optLong("updatedAt"), accountSuffix = b.optString("accountSuffix"),
                isSelected = b.optBoolean("isSelected", true)
            ))
        }
        refreshWidget()
        return restored
    }

    suspend fun import(payment: ParsedPayment): Boolean = importMutex.withLock {
        val normalizedTimestamp = if (payment.timestamp in 1..99_999_999_999L) payment.timestamp * 1000L else payment.timestamp
        val normalizedPayment = payment.copy(timestamp = normalizedTimestamp)
        val normalizedReference = normalizedPayment.reference
            .uppercase(java.util.Locale.ROOT).replace(Regex("[^A-Z0-9]"), "")
        val identity = if (normalizedReference.isNotBlank()) {
            "REF|$normalizedReference|${normalizedPayment.amountPaise}|${normalizedPayment.type}"
        } else {
            // Source-independent fingerprint: raw SMS and notification text are not identical.
            "TX|${normalizedPayment.amountPaise}|${normalizedPayment.type}|${normalizedPayment.timestamp / 60_000L}|${normalizedPayment.bankName.lowercase()}|${normalizedPayment.accountSuffix}|${normalizedPayment.merchant.normalizedForMatch()}"
        }
        val key = java.security.MessageDigest.getInstance("SHA-256")
            .digest(identity.toByteArray()).joinToString("") { "%02x".format(it) }
        if (dao.findByKey(key) != null) return false

        // A reference can be missing from one source. Compare amount/type within a short time
        // window, then validate bank/account and merchant where both sources provide them.
        val candidates = dao.findDuplicateCandidates(
            normalizedPayment.amountPaise,
            normalizedPayment.type,
            normalizedPayment.timestamp - DUPLICATE_WINDOW_MS,
            normalizedPayment.timestamp + DUPLICATE_WINDOW_MS
        )
        val incomingBank = normalizedPayment.bankName.normalizedForMatch()
        val incomingMerchant = normalizedPayment.merchant.normalizedForMatch()
        val duplicate = candidates.any { existing ->
            val sameAccount = normalizedPayment.accountSuffix.isBlank() || existing.accountSuffix.isBlank() ||
                normalizedPayment.accountSuffix == existing.accountSuffix
            val existingBank = existing.bankName.normalizedForMatch()
            val sameBank = incomingBank == "unknownbank" || existingBank == "unknownbank" || incomingBank == existingBank
            val existingMerchant = existing.merchant.normalizedForMatch()
            val genericMerchant = setOf("upitransfer", "banktransaction", "payment", "unknown")
            val sameMerchant = incomingMerchant == existingMerchant || incomingMerchant in genericMerchant || existingMerchant in genericMerchant
            val incomingIsSms = normalizedPayment.source.contains("SMS", ignoreCase = true)
            val existingIsSms = existing.source.contains("SMS", ignoreCase = true)
            val incomingIsNotification = normalizedPayment.source.contains("NOTIFICATION", ignoreCase = true)
            val existingIsNotification = existing.source.contains("NOTIFICATION", ignoreCase = true)
            val crossSource = (incomingIsSms && existingIsNotification) || (incomingIsNotification && existingIsSms)
            val hasStrongBankMatch = incomingBank != "unknownbank" && incomingBank == existingBank
            val hasStrongAccountMatch = normalizedPayment.accountSuffix.isNotBlank() &&
                existing.accountSuffix.isNotBlank() && normalizedPayment.accountSuffix == existing.accountSuffix
            crossSource && sameAccount && sameBank && (sameMerchant || hasStrongBankMatch || hasStrongAccountMatch)
        }
        if (duplicate) return false

        dao.insert(Transaction(
            amountPaise = normalizedPayment.amountPaise,
            type = normalizedPayment.type,
            merchant = normalizedPayment.merchant,
            category = CategoryRules.suggest(normalizedPayment.merchant + " " + normalizedPayment.raw),
            source = normalizedPayment.source,
            reference = normalizedPayment.reference,
            timestamp = normalizedPayment.timestamp,
            importKey = key,
            bankName = normalizedPayment.bankName,
            accountSuffix = normalizedPayment.accountSuffix,
            comment = ""
        ))
        refreshWidget()
        true
    }

    private fun String.normalizedForMatch(): String =
        lowercase(java.util.Locale.ROOT).replace(Regex("[^a-z0-9]"), "")

    companion object {
        private const val DUPLICATE_WINDOW_MS = 3 * 60 * 1000L
        private val companionImportMutex = Mutex()
    }
}
