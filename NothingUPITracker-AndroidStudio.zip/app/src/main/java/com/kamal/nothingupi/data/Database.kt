package com.kamal.nothingupi.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE importKey = :key LIMIT 1")
    suspend fun findByKey(key: String): Transaction?

    @Insert
    suspend fun insert(item: Transaction): Long

    @Query("UPDATE transactions SET category = :category WHERE id = :id")
    suspend fun updateCategory(id: Long, category: String)

    @Query("UPDATE transactions SET category = 'Other'")
    suspend fun resetCategories()

    @Query("SELECT COALESCE(SUM(amountPaise),0) FROM transactions WHERE type='EXPENSE' AND timestamp >= :start AND timestamp < :end")
    suspend fun expenseTotal(start: Long, end: Long): Long
}

@Database(entities = [Transaction::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactions(): TransactionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "nothing_upi.db"
            ).build().also { INSTANCE = it }
        }
    }
}
