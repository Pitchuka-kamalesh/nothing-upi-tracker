package com.kamal.nothingupi.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "budgets", primaryKeys = ["category"])
data class BudgetEntity(val category: String, val monthlyLimitPaise: Long, val updatedAt: Long = System.currentTimeMillis())

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE importKey = :key LIMIT 1")
    suspend fun findByKey(key: String): Transaction?

    @Insert
    suspend fun insert(item: Transaction): Long

    @Query("UPDATE transactions SET category = :category WHERE id = :id")
    suspend fun updateCategory(id: Long, category: String)

    @Query("UPDATE transactions SET category = 'Other'")
    suspend fun resetCategories()

    @Query("SELECT COALESCE(SUM(amountPaise),0) FROM transactions WHERE type='EXPENSE' AND timestamp >= :start AND timestamp < :end")
    suspend fun expenseTotal(start: Long, end: Long): Long

    @Query("SELECT * FROM budgets ORDER BY category")
    fun observeBudgets(): Flow<List<BudgetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveBudget(item: BudgetEntity)
}

@Database(entities = [Transaction::class, BudgetEntity::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactions(): TransactionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE transactions ADD COLUMN bankName TEXT NOT NULL DEFAULT 'Unknown bank'")
                db.execSQL("ALTER TABLE transactions ADD COLUMN accountSuffix TEXT NOT NULL DEFAULT ''")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS budgets (category TEXT NOT NULL, monthlyLimitPaise INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(category))")
            }
        }
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "nothing_upi.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { INSTANCE = it }
        }
    }
}

class TransactionRepository(context: Context) {
    private val appContext = context.applicationContext
    private val dao = AppDatabase.get(appContext).transactions()
    fun observe() = dao.observeAll()
    fun observeBudgets() = dao.observeBudgets()
    suspend fun saveBudget(category: String, amountPaise: Long) = dao.saveBudget(BudgetEntity(category, amountPaise))

    suspend fun add(item: Transaction): Long {
        val id = dao.insert(item)
        refreshWidget()
        return id
    }

    suspend fun setCategory(id: Long, category: String) = dao.updateCategory(id, category)

    suspend fun resetCategories() {
        dao.resetCategories()
        refreshWidget()
    }

    private suspend fun refreshWidget() {
        runCatching {
            androidx.glance.appwidget.GlanceAppWidgetManager(appContext)
                .getGlanceIds(com.kamal.nothingupi.widget.ExpenseWidget::class.java)
                .forEach { com.kamal.nothingupi.widget.ExpenseWidget().update(appContext, it) }
        }
    }

    suspend fun import(payment: ParsedPayment): Boolean {
        val identity = payment.reference.ifBlank {
            "${payment.amountPaise}|${payment.type}|${payment.merchant.lowercase()}|${payment.timestamp}|${payment.raw.take(120)}"
        }
        val key = java.security.MessageDigest.getInstance("SHA-256")
            .digest(identity.toByteArray()).joinToString("") { "%02x".format(it) }
        if (dao.findByKey(key) != null) return false
        dao.insert(Transaction(
            amountPaise = payment.amountPaise,
            type = payment.type,
            merchant = payment.merchant,
            category = CategoryRules.suggest(payment.merchant + " " + payment.raw),
            source = payment.source,
            reference = payment.reference,
            timestamp = payment.timestamp,
            importKey = key,
            bankName = payment.bankName,
            accountSuffix = payment.accountSuffix
        ))
        refreshWidget()
        return true
    }
}
