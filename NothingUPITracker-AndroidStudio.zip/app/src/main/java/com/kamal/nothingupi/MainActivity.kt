package com.kamal.nothingupi

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kamal.nothingupi.capture.Importers
import com.kamal.nothingupi.data.TransactionRepository
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

private val Black = Color(0xFF080808)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFE60012)
private val Green = Color(0xFF00C781)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val repo = remember { TransactionRepository(this) }
            val scope = rememberCoroutineScope()
            var csvMode by remember { mutableStateOf(false) }
            val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
                if (uri != null) scope.launch {
                    if (csvMode) Importers.importCsv(this@MainActivity, uri)
                    else Importers.importText(this@MainActivity, uri, "SMS")
                }
            }
            val rows by repo.observe().collectAsState(initial = emptyList())
            val monthStart = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val todayStart = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val monthSpent = rows.filter { it.type == "EXPENSE" && it.timestamp >= monthStart }.sumOf { it.amountPaise }
            val todaySpent = rows.filter { it.type == "EXPENSE" && it.timestamp >= todayStart }.sumOf { it.amountPaise }

            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel)) {
                Column(Modifier.fillMaxSize().background(Black).padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("UPI / TRACKER", color = Color.White, fontSize = 22.sp)
                        Text("● LOCAL", color = Green, fontSize = 11.sp)
                    }
                    Text("NOTHING EDITION · PRIVATE ON DEVICE", color = Color.Gray, fontSize = 10.sp)
                    Spacer(Modifier.height(16.dp))
                    MetricCard("TODAY'S SPENDING", money(todaySpent), Red, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    MetricCard("MONTHLY SPENDING", money(monthSpent), Color.White, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Button(onClick = {
                            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                        }) { Text("Enable alerts") }
                        OutlinedButton(onClick = {
                            csvMode = false; picker.launch(arrayOf("text/*"))
                        }) { Text("SMS import") }
                        OutlinedButton(onClick = {
                            csvMode = true; picker.launch(arrayOf("text/*"))
                        }) { Text("CSV import") }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("RECENT TRANSACTIONS", color = Color.White, fontSize = 13.sp)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(rows, key = { it.id }) { tx ->
                            Row(
                                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(tx.merchant, color = Color.White)
                                    Text("${tx.source} · ${tx.category}", color = Color.Gray, fontSize = 11.sp)
                                }
                                Text(
                                    (if (tx.type == "INCOME") "+ " else "− ") + money(tx.amountPaise),
                                    color = if (tx.type == "INCOME") Green else Red
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, accent: Color, modifier: Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(15.dp)).padding(14.dp)) {
        Text(label, color = Color.LightGray, fontSize = 10.sp)
        Text(value, color = accent, fontSize = 23.sp)
    }
}

private fun money(paise: Long): String =
    NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(paise / 100.0)
