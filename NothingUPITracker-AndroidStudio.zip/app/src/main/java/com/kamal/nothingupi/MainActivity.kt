package com.kamal.nothingupi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kamal.nothingupi.capture.Importers
import com.kamal.nothingupi.capture.SmsHistoryImporter
import android.widget.Toast
import com.kamal.nothingupi.data.TransactionRepository
import com.kamal.nothingupi.data.Transaction
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

private val Black = Color(0xFF080808)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFE60012)
private val Green = Color(0xFF00C781)
private val categories = listOf(
    "Other", "Savings", "Vegetables", "Groceries", "Snacks", "Food & Dining",
    "Shopping", "Travel", "Transport", "Fuel", "Bills", "Healthcare",
    "Entertainment", "Rent", "Education", "Transfer", "Cash", "Personal"
)
private val categoryEmoji = mapOf(
    "Savings" to "💰", "Vegetables" to "🥬", "Groceries" to "🛒",
    "Snacks" to "🍿", "Food & Dining" to "🍽️", "Shopping" to "🛍️",
    "Travel" to "✈️", "Transport" to "🚌", "Fuel" to "⛽",
    "Bills" to "🧾", "Healthcare" to "💊", "Entertainment" to "🎬",
    "Rent" to "🏠", "Education" to "📚", "Transfer" to "↔️",
    "Cash" to "💵", "Personal" to "👤", "Other" to "📦"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val repo = remember { TransactionRepository(this) }
            val scope = rememberCoroutineScope()
            var csvMode by remember { mutableStateOf(false) }
            var period by remember { mutableStateOf("MONTH") }
            var showResetConfirm by remember { mutableStateOf(false) }
            var smsPermissionGranted by remember {
                mutableStateOf(ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED)
            }
            var readSmsGranted by remember {
                mutableStateOf(ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED)
            }
            val smsPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
                smsPermissionGranted = result[Manifest.permission.RECEIVE_SMS] == true || ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
                readSmsGranted = result[Manifest.permission.READ_SMS] == true || ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
            }
            val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
                if (uri != null) scope.launch {
                    if (csvMode) Importers.importCsv(this@MainActivity, uri)
                    else Importers.importText(this@MainActivity, uri, "SMS")
                }
            }
            val rows by repo.observe().collectAsState(initial = emptyList())
            val now = Calendar.getInstance()
            val monthStart = (now.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val yearStart = (now.clone() as Calendar).apply {
                set(Calendar.MONTH, Calendar.JANUARY); set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val todayStart = (now.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val todaySpent = rows.filter { it.type == "EXPENSE" && it.timestamp >= todayStart }.sumOf { it.amountPaise }
            val monthSpent = rows.filter { it.type == "EXPENSE" && it.timestamp >= monthStart }.sumOf { it.amountPaise }
            val yearSpent = rows.filter { it.type == "EXPENSE" && it.timestamp >= yearStart }.sumOf { it.amountPaise }
            val displayedTotal = if (period == "MONTH") monthSpent else yearSpent

            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel)) {
                Column(Modifier.fillMaxSize().background(Black).statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("UPI / TRACKER", color = Color.White, fontSize = 22.sp)
                        Text("● LOCAL", color = Green, fontSize = 11.sp)
                    }
                    Text("NOTHING EDITION · PRIVATE ON DEVICE", color = Color.Gray, fontSize = 10.sp)
                    Spacer(Modifier.height(14.dp))
                    MetricCard("TODAY'S SPENDING", money(todaySpent), Red, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = period == "MONTH", onClick = { period = "MONTH" }, label = { Text("Monthly") })
                        FilterChip(selected = period == "YEAR", onClick = { period = "YEAR" }, label = { Text("Yearly") })
                    }
                    MetricCard(if (period == "MONTH") "MONTHLY SPENDING" else "YEARLY SPENDING", money(displayedTotal), Color.White, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }) { Text("Alerts") }
                        OutlinedButton(onClick = {
                            if (!smsPermissionGranted || !readSmsGranted) {
                                smsPermissionLauncher.launch(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS))
                            } else {
                                scope.launch {
                                    runCatching { SmsHistoryImporter.importInbox(this@MainActivity) }
                                        .onSuccess { count -> Toast.makeText(this@MainActivity, "Imported $count old payment SMS", Toast.LENGTH_LONG).show() }
                                        .onFailure { error -> Toast.makeText(this@MainActivity, error.message ?: "SMS import failed", Toast.LENGTH_LONG).show() }
                                }
                            }
                        }) { Text(if (smsPermissionGranted && readSmsGranted) "Import old SMS" else "Allow SMS") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { csvMode = false; picker.launch(arrayOf("text/*")) }) { Text("SMS import") }
                        OutlinedButton(onClick = { csvMode = true; picker.launch(arrayOf("text/*")) }) { Text("CSV import") }
                        TextButton(onClick = { showResetConfirm = true }) { Text("Reset categories", color = Red) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("CATEGORY-WISE SPENDING", color = Color.White, fontSize = 13.sp)
                    val categoryTotals = rows
                        .filter { it.type == "EXPENSE" && it.timestamp >= if (period == "MONTH") monthStart else yearStart }
                        .groupBy { it.category }
                        .mapValues { entry -> entry.value.sumOf { it.amountPaise } }
                        .toList().sortedByDescending { it.second }
                    val maxCategoryTotal = categoryTotals.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            if (categoryTotals.isEmpty()) {
                                Text("No expenses in this period yet.", color = Color.Gray, fontSize = 12.sp)
                            } else {
                                categoryTotals.forEach { (category, total) ->
                                    CategorySpendingRow(category, total, maxCategoryTotal)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("TRANSACTIONS · PICK A CATEGORY", color = Color.White, fontSize = 13.sp)
                        }
                        items(rows, key = { it.id }) { tx ->
                            TransactionRow(tx = tx, onCategory = { category -> scope.launch { repo.setCategory(tx.id, category) } })
                        }
                    }
                }
                if (showResetConfirm) {
                    AlertDialog(
                        onDismissRequest = { showResetConfirm = false },
                        title = { Text("Reset all categories?") },
                        text = { Text("All transactions will be set to Other. You can then choose categories individually.") },
                        confirmButton = {
                            TextButton(onClick = { scope.launch { repo.resetCategories() }; showResetConfirm = false }) { Text("Reset", color = Red) }
                        },
                        dismissButton = { TextButton(onClick = { showResetConfirm = false }) { Text("Cancel") } }
                    )
                }
            }
        }
    }
}


@Composable
private fun CategorySpendingRow(category: String, total: Long, maxTotal: Long) {
    val progress = (total.toFloat() / maxTotal.toFloat()).coerceIn(0f, 1f)
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(categoryEmoji[category] ?: "📦", fontSize = 22.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(category, color = Color.White, fontSize = 12.sp)
                Text(money(total), color = Color.White, fontSize = 12.sp)
            }
            Spacer(Modifier.height(5.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(5.dp),
                color = Red,
                trackColor = Color(0xFF383838)
            )
        }
    }
}

@Composable
private fun TransactionRow(tx: Transaction, onCategory: (String) -> Unit) {
    var expanded by remember(tx.id) { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(tx.merchant, color = Color.White)
            Text("${tx.source} · ${tx.category}", color = Color.Gray, fontSize = 11.sp)
            Box {
                TextButton(onClick = { expanded = true }, contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)) { Text("Change category", color = Color(0xFFBDBDBD), fontSize = 11.sp) }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    categories.forEach { category ->
                        DropdownMenuItem(text = { Text(category) }, onClick = { onCategory(category); expanded = false })
                    }
                }
            }
        }
        Text((if (tx.type == "INCOME") "+ " else "− ") + money(tx.amountPaise), color = if (tx.type == "INCOME") Green else Red)
    }
}

@Composable
private fun MetricCard(label: String, value: String, accent: Color, modifier: Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(15.dp)).padding(14.dp)) {
        Text(label, color = Color.LightGray, fontSize = 10.sp)
        Text(value, color = accent, fontSize = 23.sp)
    }
}

private fun money(paise: Long): String = NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(paise / 100.0)
