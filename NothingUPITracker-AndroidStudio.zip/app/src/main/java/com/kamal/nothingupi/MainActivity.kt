package com.kamal.nothingupi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kamal.nothingupi.capture.Importers
import com.kamal.nothingupi.capture.SmsHistoryImporter
import com.kamal.nothingupi.data.Transaction
import com.kamal.nothingupi.data.BankAccountEntity
import com.kamal.nothingupi.data.TransactionRepository
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Black = Color(0xFF080808)
private val Panel = Color(0xFF171717)
private val Panel2 = Color(0xFF222222)
private val Red = Color(0xFFE60012)
private val Green = Color(0xFF00C781)
private val Muted = Color(0xFF9A9A9A)
private val categories = listOf("Other", "Savings", "Vegetables", "Groceries", "Snacks", "Food & Dining", "Shopping", "Travel", "Transport", "Fuel", "Bills", "Healthcare", "Entertainment", "Rent", "Education", "Transfer", "Cash", "Personal")
private val categoryEmoji = mapOf("Savings" to "💰", "Vegetables" to "🥬", "Groceries" to "🛒", "Snacks" to "🍿", "Food & Dining" to "🍽️", "Shopping" to "🛍️", "Travel" to "✈️", "Transport" to "🚌", "Fuel" to "⛽", "Bills" to "🧾", "Healthcare" to "💊", "Entertainment" to "🎬", "Rent" to "🏠", "Education" to "📚", "Transfer" to "↔️", "Cash" to "💵", "Personal" to "👤", "Other" to "📦")

private enum class Tab(val label: String) { HOME("Home"), TRANSACTIONS("Activity"), BANKS("Banks"), CATEGORIES("Categories"), MORE("More") }

class MainActivity : ComponentActivity() {
    private var notificationAccessGranted by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshNotificationAccess()
        setContent {
            val repo = remember { TransactionRepository(this) }
            val scope = rememberCoroutineScope()
            val rows by repo.observe().collectAsState(initial = emptyList())
            val budgets by repo.observeBudgets().collectAsState(initial = emptyList())
            val bankAccounts by repo.observeBankAccounts().collectAsState(initial = emptyList())
            LaunchedEffect(Unit) {
                val bankPrefs = getSharedPreferences("bank_setup", MODE_PRIVATE)
                if (!bankPrefs.getBoolean("seeded", false)) {
                    repo.seedDefaultBankAccounts()
                    bankPrefs.edit().putBoolean("seeded", true).apply()
                }
            }
            var tab by remember { mutableStateOf(Tab.HOME) }
            var period by remember { mutableStateOf("MONTH") }
            var csvMode by remember { mutableStateOf(false) }
            var showResetConfirm by remember { mutableStateOf(false) }
            var pendingDeleteIds by remember { mutableStateOf<List<Long>>(emptyList()) }
            var importing by remember { mutableStateOf(false) }
            val prefs = remember { getSharedPreferences("private_lock", MODE_PRIVATE) }
            var pinHash by remember { mutableStateOf(prefs.getString("pin_hash", null)) }
            var locked by remember { mutableStateOf(pinHash != null) }
            var unlockPin by remember { mutableStateOf("") }
            var smsPermissionGranted by remember { mutableStateOf(ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) }
            var readSmsGranted by remember { mutableStateOf(ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) }
            val smsPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
                smsPermissionGranted = result[Manifest.permission.RECEIVE_SMS] == true || ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
                readSmsGranted = result[Manifest.permission.READ_SMS] == true || ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
                if (readSmsGranted) scope.launch { runImport() { SmsHistoryImporter.importInbox(this@MainActivity) } }
            }
            val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
                if (uri != null) scope.launch { runCatching { if (csvMode) Importers.importCsv(this@MainActivity, uri) else Importers.importText(this@MainActivity, uri, "SMS") }.onFailure { Toast.makeText(this@MainActivity, it.message ?: "Import failed", Toast.LENGTH_LONG).show() } }
            }
            val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
                if (uri != null) scope.launch { runCatching {
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { out ->
                        out.write("date,type,amount,merchant,category,bank,account,source,reference,comment\n")
                        rows.forEach { tx ->
                            val fields = listOf(dateTimeLabel(tx.timestamp), tx.type, (tx.amountPaise / 100.0).toString(), tx.merchant, tx.category, tx.bankName, tx.accountSuffix, tx.source, tx.reference, tx.comment)
                            out.write(fields.joinToString(",") { field -> "\"${field.replace("\"", "\"\"")}\"" } + "\n")
                        }
                    } ?: error("Cannot create export file")
                }.onSuccess { Toast.makeText(this@MainActivity, "CSV exported", Toast.LENGTH_SHORT).show() }.onFailure { Toast.makeText(this@MainActivity, it.message ?: "Export failed", Toast.LENGTH_LONG).show() } }
            }
            val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
                if (uri != null) runCatching {
                    val array = org.json.JSONArray()
                    rows.forEach { tx -> array.put(org.json.JSONObject().put("id", tx.id).put("amountPaise", tx.amountPaise).put("type", tx.type).put("merchant", tx.merchant).put("category", tx.category).put("source", tx.source).put("reference", tx.reference).put("timestamp", tx.timestamp).put("importKey", tx.importKey).put("bankName", tx.bankName).put("accountSuffix", tx.accountSuffix).put("comment", tx.comment)) }
                    val root = org.json.JSONObject().put("format", "nothing-upi-backup-v1").put("createdAt", System.currentTimeMillis()).put("transactions", array)
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(root.toString(2)) } ?: error("Cannot create backup")
                    Toast.makeText(this@MainActivity, "JSON backup saved", Toast.LENGTH_SHORT).show()
                }.onFailure { Toast.makeText(this@MainActivity, it.message ?: "Backup failed", Toast.LENGTH_LONG).show() }
            }
            val now = Calendar.getInstance()
            val monthStart = (now.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            val yearStart = (now.clone() as Calendar).apply { set(Calendar.MONTH, Calendar.JANUARY); set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            val todayStart = (now.clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            val tomorrowStart = todayStart + 24L * 60 * 60 * 1000
            val todayRows = rows.filter { it.timestamp >= todayStart && it.timestamp < tomorrowStart }
            val todayCredit = todayRows.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
            val todayDebit = todayRows.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
            val periodRows = rows.filter { it.timestamp >= if (period == "MONTH") monthStart else yearStart }
            val periodCredit = periodRows.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
            val periodDebit = periodRows.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }

            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel)) {
                if (locked) {
                    Column(Modifier.fillMaxSize().background(Black).statusBarsPadding().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("NOTHING / PRIVATE", color = Color.White, fontSize = 22.sp)
                        Text("Enter your app PIN", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
                        OutlinedTextField(value = unlockPin, onValueChange = { unlockPin = it.filter(Char::isDigit).take(6) }, label = { Text("PIN") }, singleLine = true)
                        Button(onClick = {
                            val candidate = java.security.MessageDigest.getInstance("SHA-256").digest(unlockPin.toByteArray()).joinToString("") { "%02x".format(it) }
                            if (candidate == pinHash) { locked = false; unlockPin = "" } else { unlockPin = ""; Toast.makeText(this@MainActivity, "Incorrect PIN", Toast.LENGTH_SHORT).show() }
                        }, modifier = Modifier.padding(top = 12.dp), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Unlock") }
                    }
                } else Scaffold(containerColor = Black, contentWindowInsets = WindowInsets(0), bottomBar = {
                    NavigationBar(containerColor = Color(0xFF101010), tonalElevation = 0.dp) {
                        Tab.values().forEach { item ->
                            NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = {
                                Icon(when (item) { Tab.HOME -> Icons.Default.Home; Tab.TRANSACTIONS -> Icons.Default.ReceiptLong; Tab.BANKS -> Icons.Default.AccountBalance; Tab.CATEGORIES -> Icons.Default.Category; Tab.MORE -> Icons.Default.Settings }, contentDescription = item.label)
                            }, label = { Text(item.label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, selectedTextColor = Color.White, indicatorColor = Color(0xFF302020), unselectedIconColor = Muted, unselectedTextColor = Muted))
                        }
                    }
                }) { padding ->
                    Column(Modifier.fillMaxSize().background(Black).statusBarsPadding().padding(padding).padding(horizontal = 16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 2.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column { Text("DotLedger", color = Color.White, fontSize = 23.sp); Text("YOUR MONEY. CLEARLY TRACKED.", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp) }
                            Text("● LOCAL", color = Green, fontSize = 10.sp)
                        }
                        when (tab) {
                            Tab.HOME -> HomeScreen(rows, todayCredit, todayDebit, periodCredit, periodDebit, period, { period = it }, { tab = Tab.TRANSACTIONS }, { tab = Tab.BANKS })
                            Tab.TRANSACTIONS -> TransactionsScreen(rows, onCategory = { tx, category -> scope.launch { repo.setCategory(tx.id, category) } }, onComment = { tx, comment -> scope.launch { repo.setComment(tx.id, comment) } }, onDelete = { ids -> pendingDeleteIds = ids }, onImport = {
                                if (!smsPermissionGranted || !readSmsGranted) smsPermissionLauncher.launch(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS))
                                else scope.launch { runImport() { SmsHistoryImporter.importInbox(this@MainActivity) } }
                            }, onCsv = { csvMode = true; picker.launch(arrayOf("text/*")) }, onSmsFile = { csvMode = false; picker.launch(arrayOf("text/*")) })
                            Tab.BANKS -> BanksScreen(
                                rows = rows,
                                accounts = bankAccounts,
                                onSaveBalance = { bank, paise, type, suffix -> scope.launch { repo.saveBankBalance(bank, paise, type, suffix); Toast.makeText(this@MainActivity, "$bank balance saved", Toast.LENGTH_SHORT).show() } },
                                onDeleteBank = { bank -> scope.launch { repo.deleteBankAccount(bank); Toast.makeText(this@MainActivity, "$bank removed from bank list", Toast.LENGTH_SHORT).show() } }
                            )
                            Tab.CATEGORIES -> CategoriesScreen(rows, period, { period = it }, onCategory = { tx, category -> scope.launch { repo.setCategory(tx.id, category) } }, onComment = { tx, comment -> scope.launch { repo.setComment(tx.id, comment) } }, onReset = { showResetConfirm = true })
                            Tab.MORE -> MoreScreen(rows, budgets, pinHash != null, notificationAccessGranted,
                                onOpenNotificationSettings = { runCatching { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }.onFailure { Toast.makeText(this@MainActivity, "Open Android Settings → Special app access → Notification access", Toast.LENGTH_LONG).show() } },
                                onSetPin = { pin -> val hash = java.security.MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString("") { "%02x".format(it) }; prefs.edit().putString("pin_hash", hash).apply(); pinHash = hash; Toast.makeText(this@MainActivity, "App PIN enabled", Toast.LENGTH_SHORT).show() }, onDisablePin = { prefs.edit().remove("pin_hash").apply(); pinHash = null }, onSaveBudget = { category, amount -> scope.launch { repo.saveBudget(category, amount) } }, onExport = { exportLauncher.launch("nothing-upi-transactions.csv") }, onBackup = { backupLauncher.launch("nothing-upi-backup.json") })
                        }
                    }
                }
                if (!locked && showResetConfirm) AlertDialog(
                    onDismissRequest = { showResetConfirm = false },
                    title = { Text("Reset all categories?") },
                    text = { Text("Every saved transaction category will be reset to Other. Transactions and amounts will not be deleted.") },
                    confirmButton = { TextButton(onClick = { scope.launch { runCatching { repo.resetCategories() }.onSuccess { Toast.makeText(this@MainActivity, "All categories reset", Toast.LENGTH_SHORT).show() }.onFailure { Toast.makeText(this@MainActivity, "Reset failed: ${it.message}", Toast.LENGTH_LONG).show() } }; showResetConfirm = false }) { Text("Reset", color = Red) } },
                    dismissButton = { TextButton(onClick = { showResetConfirm = false }) { Text("Cancel") } }
                )
                if (!locked && pendingDeleteIds.isNotEmpty()) AlertDialog(
                    onDismissRequest = { pendingDeleteIds = emptyList() },
                    title = { Text(if (pendingDeleteIds.size == 1) "Delete transaction?" else "Delete ${pendingDeleteIds.size} transactions?") },
                    text = { Text("This removes the selected records from DotLedger only. Original SMS messages in your phone inbox will not be deleted.") },
                    confirmButton = { TextButton(onClick = { val ids = pendingDeleteIds; scope.launch { runCatching { repo.deleteTransactions(ids) }.onSuccess { Toast.makeText(this@MainActivity, "Deleted ${ids.size} transaction(s)", Toast.LENGTH_SHORT).show() }.onFailure { Toast.makeText(this@MainActivity, "Delete failed: ${it.message}", Toast.LENGTH_LONG).show() } }; pendingDeleteIds = emptyList() }) { Text("Delete", color = Red) } },
                    dismissButton = { TextButton(onClick = { pendingDeleteIds = emptyList() }) { Text("Cancel") } }
                )
            }
        }
    }

    private suspend fun runImport(block: suspend () -> Int) {
        runCatching { block() }.onSuccess { Toast.makeText(this, "Imported $it old payment SMS", Toast.LENGTH_LONG).show() }.onFailure { Toast.makeText(this, it.message ?: "SMS import failed", Toast.LENGTH_LONG).show() }
    }

    override fun onResume() {
        super.onResume()
        refreshNotificationAccess()
    }

    private fun refreshNotificationAccess() {
        val enabledListeners = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_NOTIFICATION_LISTENERS
        ).orEmpty()
        notificationAccessGranted = enabledListeners.split(":").any { component ->
            component.contains(packageName)
        }
    }
}

@Composable private fun HomeScreen(rows: List<Transaction>, todayCredit: Long, todayDebit: Long, credit: Long, debit: Long, period: String, onPeriod: (String) -> Unit, onActivity: () -> Unit, onBanks: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(14.dp))
        Text("TODAY · ${dateLabel(System.currentTimeMillis())}", color = Muted, fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("CREDIT / DEPOSIT", money(todayCredit), Green, Modifier.weight(1f))
            MetricCard("DEBIT / SPENT", money(todayDebit), Red, Modifier.weight(1f))
        }
        val netToday = todayCredit - todayDebit
        Text("Today's net flow  ${if (netToday >= 0) "+" else "−"}${money(kotlin.math.abs(netToday))}", color = if (netToday >= 0) Green else Red, fontSize = 12.sp, modifier = Modifier.padding(vertical = 9.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("PERIOD SUMMARY", color = Color.White, fontSize = 13.sp)
            Row { FilterChip(period == "MONTH", { onPeriod("MONTH") }, label = { Text("Month") }); Spacer(Modifier.width(5.dp)); FilterChip(period == "YEAR", { onPeriod("YEAR") }, label = { Text("Year") }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("MONEY IN", money(credit), Green, Modifier.weight(1f))
            MetricCard("MONEY OUT", money(debit), Red, Modifier.weight(1f))
        }
        Text("BY DATE", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 15.dp, bottom = 8.dp))
        val daily = rows.groupBy { dateKey(it.timestamp) }.toList().sortedByDescending { it.first }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(daily) { (date, txs) ->
                val ins = txs.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
                val outs = txs.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(date, color = Color.White, fontSize = 13.sp); Text("${txs.size} transactions", color = Muted, fontSize = 10.sp) }
                    Column(horizontalAlignment = Alignment.End) { Text("+ ${money(ins)}", color = Green, fontSize = 12.sp); Text("− ${money(outs)}", color = Red, fontSize = 12.sp) }
                }
            }
            if (daily.isEmpty()) item { EmptyState("No transactions yet", "Import your SMS history or enable notification access.") }
        }
    }
}

@Composable private fun TransactionsScreen(
    rows: List<Transaction>,
    onCategory: (Transaction, String) -> Unit,
    onComment: (Transaction, String) -> Unit,
    onDelete: (List<Long>) -> Unit,
    onImport: () -> Unit,
    onCsv: () -> Unit,
    onSmsFile: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var sourceFilter by remember { mutableStateOf("ALL") }
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }
    val filtered = remember(rows, query, sourceFilter) { rows.filter { tx ->
        val q = query.trim().lowercase()
        val sourceMatches = when (sourceFilter) {
            "SMS" -> tx.source.contains("SMS", ignoreCase = true)
            "NOTIFICATION" -> tx.source.contains("NOTIFICATION", ignoreCase = true)
            "CSV" -> tx.source.contains("CSV", ignoreCase = true)
            else -> true
        }
        sourceMatches && (q.isBlank() || listOf(tx.merchant, tx.bankName, tx.category, tx.source, tx.reference, tx.accountSuffix, tx.comment, money(tx.amountPaise)).any { it.lowercase().contains(q) })
    } }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), placeholder = { Text("Search amount, bank, UPI ID, merchant…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = onImport, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Import inbox") }
            OutlinedButton(onClick = onCsv) { Text("CSV") }
            OutlinedButton(onClick = onSmsFile) { Text("SMS file") }
        }
        Text("FILTER IMPORTED DATA", color = Muted, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("ALL", "SMS", "NOTIFICATION", "CSV").forEach { filter ->
                FilterChip(selected = sourceFilter == filter, onClick = { sourceFilter = filter; selectedIds = emptySet() }, label = { Text(filter.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 10.sp) })
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${filtered.size} RECORDS · DATE ORDER", color = Muted, fontSize = 10.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selectedIds = if (selectedIds.size == filtered.size) emptySet() else filtered.map { it.id }.toSet() }) { Text(if (selectedIds.size == filtered.size && filtered.isNotEmpty()) "Clear" else "Select all", color = Red, fontSize = 10.sp) }
                if (selectedIds.isNotEmpty()) {
                    TextButton(onClick = { onDelete(selectedIds.toList()) }) {
                        Icon(Icons.Default.DeleteSweep, null, tint = Red, modifier = Modifier.size(16.dp))
                        Text("Delete ${selectedIds.size}", color = Red, fontSize = 10.sp)
                    }
                }
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { tx ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = tx.id in selectedIds, onCheckedChange = { checked -> selectedIds = if (checked) selectedIds + tx.id else selectedIds - tx.id })
                    Box(Modifier.weight(1f)) { TransactionRow(tx, onCategory, onComment, onDelete = { onDelete(listOf(it.id)) }) }
                }
            }
            if (filtered.isEmpty()) item { EmptyState(if (rows.isEmpty()) "Nothing captured yet" else "No matching transactions", "Try another filter or import your payment SMS.") }
        }
    }
}

@Composable private fun BanksScreen(
    rows: List<Transaction>,
    accounts: List<BankAccountEntity>,
    onSaveBalance: (String, Long, String, String) -> Unit,
    onDeleteBank: (String) -> Unit
) {
    var balanceType by remember { mutableStateOf("CURRENT") }
    var pendingDelete by remember { mutableStateOf<String?>(null) }
    val bankGroups = rows.groupBy { it.bankName }
    Column(Modifier.fillMaxSize()) {
        Text("MY BANK ACCOUNTS", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
        Text("Save today's balance separately from UPI income and expenses.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(bottom = 10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 10.dp)) {
            FilterChip(selected = balanceType == "CURRENT", onClick = { balanceType = "CURRENT" }, label = { Text("Current balance") })
            FilterChip(selected = balanceType == "OPENING", onClick = { balanceType = "OPENING" }, label = { Text("Opening balance") })
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(accounts, key = { it.bankName }) { account ->
                val txs = bankGroups[account.bankName].orEmpty()
                val credit = txs.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
                val debit = txs.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
                var amountText by remember(account.bankName, account.balancePaise, account.updatedAt) { mutableStateOf(if (account.balancePaise == 0L) "" else "%.2f".format(Locale.US, account.balancePaise / 100.0)) }
                var suffix by remember(account.bankName, account.accountSuffix) { mutableStateOf(account.accountSuffix) }
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBalance, null, tint = Red)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(account.bankName, color = Color.White, fontSize = 14.sp)
                            Text(if (account.accountSuffix.isBlank()) "Account nickname / last 4 digits optional" else "Account ••${account.accountSuffix}", color = Muted, fontSize = 10.sp)
                        }
                        IconButton(onClick = { pendingDelete = account.bankName }) { Icon(Icons.Default.Delete, contentDescription = "Remove bank", tint = Muted) }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = amountText, onValueChange = { amountText = it.filter { ch -> ch.isDigit() || ch == '.' }.take(12) },
                        modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("${if (balanceType == "CURRENT") "Current" else "Opening"} balance (₹)") },
                        placeholder = { Text("0.00") }
                    )
                    OutlinedTextField(value = suffix, onValueChange = { suffix = it.filter(Char::isDigit).take(4) }, modifier = Modifier.fillMaxWidth().padding(top = 5.dp), singleLine = true, label = { Text("Last 4 account digits (optional)") })
                    Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            if (account.updatedAt > 0L) {
                                Text("Saved: ${money(account.balancePaise)}", color = Green, fontSize = 11.sp)
                                Text("Updated ${dateTimeLabel(account.updatedAt)} · ${account.balanceType.lowercase().replaceFirstChar { it.uppercase() }}", color = Muted, fontSize = 9.sp)
                            } else Text("Balance not saved yet", color = Muted, fontSize = 10.sp)
                        }
                        Button(onClick = {
                            val value = amountText.toBigDecimalOrNull()
                            if (value == null || value < java.math.BigDecimal.ZERO) return@Button
                            val paise = runCatching { value.movePointRight(2).setScale(0, java.math.RoundingMode.HALF_UP).longValueExact() }.getOrNull() ?: return@Button
                            onSaveBalance(account.bankName, paise, balanceType, suffix)
                        }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Save balance") }
                    }
                    Divider(Modifier.padding(vertical = 9.dp), color = Panel2)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("UPI received  ${money(credit)}", color = Green, fontSize = 10.sp)
                        Text("UPI paid  ${money(debit)}", color = Red, fontSize = 10.sp)
                    }
                }
            }
            if (accounts.isEmpty()) item { EmptyState("No banks selected", "Your bank list is empty. Add a bank account to start tracking balances.") }
        }
    }
    if (pendingDelete != null) AlertDialog(
        onDismissRequest = { pendingDelete = null },
        title = { Text("Remove ${pendingDelete}?") },
        text = { Text("This removes the bank from your saved bank list. Its UPI transaction history will remain unchanged.") },
        confirmButton = { TextButton(onClick = { pendingDelete?.let(onDeleteBank); pendingDelete = null }) { Text("Remove", color = Red) } },
        dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } }
    )
}

@Composable private fun CategoriesScreen(rows: List<Transaction>, period: String, onPeriod: (String) -> Unit, onCategory: (Transaction, String) -> Unit, onComment: (Transaction, String) -> Unit, onReset: () -> Unit) {
    var expandedCategory by remember { mutableStateOf<String?>(null) }
    val start = Calendar.getInstance().apply { if (period == "MONTH") set(Calendar.DAY_OF_MONTH, 1) else { set(Calendar.MONTH, Calendar.JANUARY); set(Calendar.DAY_OF_MONTH, 1) }; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val expenses = rows.filter { it.type == "EXPENSE" && it.timestamp >= start }
    val totals = expenses.groupBy { it.category }.mapValues { it.value.sumOf(Transaction::amountPaise) }.toList().sortedByDescending { it.second }
    val max = totals.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("SPENDING CATEGORIES", color = Color.White, fontSize = 13.sp)
            Row { FilterChip(period == "MONTH", { onPeriod("MONTH") }, label = { Text("Month") }); Spacer(Modifier.width(4.dp)); FilterChip(period == "YEAR", { onPeriod("YEAR") }, label = { Text("Year") }) }
        }
        Text("Tap a category to see the transactions inside it.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(bottom = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(totals) { (category, total) ->
                val isExpanded = expandedCategory == category
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp)).padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(categoryEmoji[category] ?: "📦", fontSize = 22.sp); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text(category, color = Color.White, fontSize = 13.sp); LinearProgressIndicator({ (total.toFloat() / max).coerceIn(0f, 1f) }, Modifier.fillMaxWidth().padding(top = 5.dp).height(4.dp), color = Red, trackColor = Panel2) }
                        Spacer(Modifier.width(8.dp)); Text(money(total), color = Color.White, fontSize = 12.sp)
                        TextButton(onClick = { expandedCategory = if (isExpanded) null else category }) { Text(if (isExpanded) "Hide" else "View", color = Red, fontSize = 10.sp) }
                    }
                    if (isExpanded) expenses.filter { it.category == category }.forEach { TransactionRow(it, onCategory, onComment) }
                }
            }
            item { OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) { Text("Reset all categories to Other", color = Red) } }
            if (totals.isEmpty()) item { EmptyState("No expenses in this period", "Your category totals will appear here after importing transactions.") }
        }
    }
}

@Composable private fun TransactionRow(
    tx: Transaction,
    onCategory: (Transaction, String) -> Unit,
    onComment: (Transaction, String) -> Unit,
    onDelete: ((Transaction) -> Unit)? = null
) {
    var expanded by remember(tx.id) { mutableStateOf(false) }
    var showCommentDialog by remember(tx.id) { mutableStateOf(false) }
    var commentDraft by remember(tx.id, tx.comment) { mutableStateOf(tx.comment) }
    Row(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF29272D), Color(0xFF171719), Color(0xFF21191C))), RoundedCornerShape(16.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(tx.merchant, color = Color.White, fontSize = 13.sp)
            Text("${dateTimeLabel(tx.timestamp)} · ${tx.bankName}", color = Muted, fontSize = 10.sp)
            Text("${tx.source} · ${tx.category}", color = Muted, fontSize = 10.sp)
            if (tx.comment.isNotBlank()) {
                Text("✎ ${tx.comment}", color = Color(0xFFCFB6FF), fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showCommentDialog = true }, contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)) {
                    Text(if (tx.comment.isBlank()) "+ Add note" else "Edit note", color = Color(0xFFCFB6FF), fontSize = 10.sp)
                }
                Spacer(Modifier.width(8.dp))
                Box { TextButton(onClick = { expanded = true }, contentPadding = PaddingValues(0.dp)) { Text("Change category", color = Color(0xFFBDBDBD), fontSize = 10.sp) }; DropdownMenu(expanded, { expanded = false }) { categories.forEach { category -> DropdownMenuItem(text = { Text("${categoryEmoji[category] ?: "📦"}  $category") }, onClick = { onCategory(tx, category); expanded = false }) } } }
            }
        }
        Column(horizontalAlignment = Alignment.End) {
            Text((if (tx.type == "INCOME") "+ " else "− ") + money(tx.amountPaise), color = if (tx.type == "INCOME") Green else Red, fontSize = 12.sp)
            if (onDelete != null) TextButton(onClick = { onDelete(tx) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Delete transaction", tint = Red, modifier = Modifier.size(14.dp))
                Text("Delete", color = Red, fontSize = 9.sp)
            }
        }
    }
    if (showCommentDialog) AlertDialog(
        onDismissRequest = { showCommentDialog = false },
        title = { Text("Payment note") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Add a private note for ${tx.merchant}", color = Muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = commentDraft,
                    onValueChange = { commentDraft = it.take(500) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("e.g. Groceries for home, rent split, office lunch…") },
                    minLines = 3,
                    maxLines = 5
                )
                Text("${commentDraft.length}/500 characters · Stored only on this device", color = Muted, fontSize = 10.sp)
            }
        },
        confirmButton = { TextButton(onClick = { onComment(tx, commentDraft); showCommentDialog = false }) { Text("Save note", color = Red) } },
        dismissButton = { TextButton(onClick = { showCommentDialog = false }) { Text("Cancel") } }
    )
}

@Composable private fun MoreScreen(rows: List<Transaction>, budgets: List<com.kamal.nothingupi.data.BudgetEntity>, pinEnabled: Boolean, notificationAccessEnabled: Boolean, onOpenNotificationSettings: () -> Unit, onSetPin: (String) -> Unit, onDisablePin: () -> Unit, onSaveBudget: (String, Long) -> Unit, onExport: () -> Unit, onBackup: () -> Unit) {
    var pinText by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Groceries") }
    var amountText by remember { mutableStateOf("") }
    val monthStart = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val monthExpenses = rows.filter { it.type == "EXPENSE" && it.timestamp >= monthStart }
    val recurring = rows.filter { it.type == "EXPENSE" }.groupBy { it.merchant.trim().lowercase() }.mapNotNull { (merchant, txs) ->
        val ordered = txs.sortedBy { it.timestamp }
        if (ordered.size >= 2) {
            val gaps = ordered.zipWithNext { a, b -> (b.timestamp - a.timestamp) / (24L * 60 * 60 * 1000) }
            if (gaps.any { it in 25..35 || it in 6..8 || it in 13..15 }) ordered.last() else null
        } else null
    }.sortedByDescending { it.timestamp }
    val possibleTransfers = rows.filter { it.category.equals("Transfer", true) || it.merchant.contains("self", true) || it.merchant.contains("own account", true) }
    val matchedTransferCandidates = rows.groupBy { dateKey(it.timestamp) + "|" + it.amountPaise }.values.flatMap { group ->
        val credits = group.filter { it.type == "INCOME" }
        val debits = group.filter { it.type == "EXPENSE" }
        credits.flatMap { credit -> debits.filter { debit -> debit.id != credit.id && debit.bankName != credit.bankName && credit.bankName != "Unknown bank" && debit.bankName != "Unknown bank" }.map { debit -> credit to debit } }
    }
    val totalIn = rows.filter { it.type == "INCOME" && it.timestamp >= monthStart }.sumOf { it.amountPaise }
    val totalOut = monthExpenses.sumOf { it.amountPaise }
    val biggest = monthExpenses.groupBy { it.category }.maxByOrNull { it.value.sumOf(Transaction::amountPaise) }
    Column(Modifier.fillMaxSize()) {
        Text("MONEY TOOLS", color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(top = 14.dp, bottom = 10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                FeaturePanel("REAL-TIME PAYMENT CAPTURE", "Capture payment notifications from supported UPI apps") {
                    Text(if (notificationAccessEnabled) "Notification access is enabled on this device." else "Notification access is not enabled. Android requires you to grant this permission manually.", color = if (notificationAccessEnabled) Green else Color(0xFFFFC857), fontSize = 11.sp)
                    Button(onClick = onOpenNotificationSettings, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                        Text(if (notificationAccessEnabled) "Manage notification access" else "Enable notification access")
                    }
                    Text("After Android Settings opens, enable DotLedger under Notification access, then return here. Supported sources are Google Pay, PhonePe, Paytm and Super.money when their notifications contain readable payment details.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                FeaturePanel("MONTHLY INSIGHTS", "Income ${money(totalIn)}   ·   Expense ${money(totalOut)}   ·   Net ${money(totalIn-totalOut)}") {
                    Text("Top category: ${biggest?.key ?: "No data"}${biggest?.value?.let { " · ${money(it.sumOf(Transaction::amountPaise))}" } ?: ""}", color = Color.White, fontSize = 12.sp)
                    Text("${monthExpenses.size} expenses this month. Insight is generated locally from your transactions; no data is sent to an AI service.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                FeaturePanel("MONTHLY BUDGETS", "Set a limit for each spending category") {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                        var menu by remember { mutableStateOf(false) }
                        Box(Modifier.weight(1f)) { OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedCategory, color = Color.White) }; DropdownMenu(menu, { menu = false }) { categories.filter { it != "Other" }.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { selectedCategory = it; menu = false }) } } }
                        OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' }.take(9) }, modifier = Modifier.weight(1f), label = { Text("₹ limit") }, singleLine = true)
                    }
                    Button(onClick = { val paise = ((amountText.toDoubleOrNull() ?: 0.0) * 100).toLong(); if (paise > 0) { onSaveBudget(selectedCategory, paise); amountText = "" } }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Save budget") }
                    budgets.forEach { b ->
                        val spent = monthExpenses.filter { it.category == b.category }.sumOf { it.amountPaise }
                        val ratio = (spent.toFloat() / b.monthlyLimitPaise.coerceAtLeast(1)).coerceIn(0f, 1f)
                        Text("${b.category}  ${money(spent)} / ${money(b.monthlyLimitPaise)}", color = Color.White, fontSize = 11.sp)
                        LinearProgressIndicator({ ratio }, Modifier.fillMaxWidth().height(5.dp), color = if (ratio >= 1f) Red else Green, trackColor = Panel2)
                        if (ratio >= .8f) Text(if (ratio >= 1f) "Budget exceeded" else "80% budget used", color = if (ratio >= 1f) Red else Color(0xFFFFC857), fontSize = 10.sp)
                    }
                    if (budgets.isEmpty()) Text("No budgets configured yet.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                FeaturePanel("RECONCILIATION", "Review possible transfers and transaction classification") {
                    Text("${possibleTransfers.size} transactions marked or suspected as transfers.", color = Color.White, fontSize = 12.sp)
                    Text("${matchedTransferCandidates.size} possible same-day, same-amount credit/debit pairs across different banks.", color = Color.White, fontSize = 12.sp)
                    matchedTransferCandidates.take(5).forEach { (credit, debit) ->
                        Text("Possible match · ${dateLabel(credit.timestamp)} · ${money(credit.amountPaise)}", color = Color(0xFFFFC857), fontSize = 11.sp)
                        Text("IN ${credit.bankName} ← / OUT ${debit.bankName} →", color = Muted, fontSize = 10.sp)
                    }
                    Text("These are candidates only, not confirmed transfers. Matching amount and date can also occur by coincidence. Review against your bank statement; matched pairs are not automatically removed from income/expense totals.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                FeaturePanel("RECURRING PAYMENT CANDIDATES", "Detected locally from repeated merchant and timing patterns") {
                    if (recurring.isEmpty()) Text("No recurring candidates yet. More history improves detection.", color = Muted, fontSize = 11.sp)
                    recurring.take(8).forEach { Text("${it.merchant} · ${money(it.amountPaise)} · ${it.bankName}", color = Color.White, fontSize = 11.sp) }
                }
            }
            item {
                FeaturePanel("REPORTS & BACKUP", "Export a portable transaction CSV") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onExport, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Export CSV") }
                        OutlinedButton(onClick = onBackup) { Text("JSON backup") }
                    }
                    Text("CSV is for reports. JSON preserves transaction fields for backup. Keep these files private. Restore/import from JSON is not available in this build.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                FeaturePanel("APP PIN LOCK", "Protect this app when it opens") {
                    if (pinEnabled) {
                        Text("PIN lock is enabled on this device.", color = Green, fontSize = 11.sp)
                        OutlinedButton(onClick = onDisablePin) { Text("Disable PIN lock") }
                    } else {
                        OutlinedTextField(value = pinText, onValueChange = { pinText = it.filter(Char::isDigit).take(6) }, label = { Text("Create 4–6 digit PIN") }, singleLine = true)
                        OutlinedTextField(value = confirmPin, onValueChange = { confirmPin = it.filter(Char::isDigit).take(6) }, label = { Text("Confirm PIN") }, singleLine = true)
                        Button(onClick = { if (pinText.length in 4..6 && pinText == confirmPin) { onSetPin(pinText); pinText = ""; confirmPin = "" } }, enabled = pinText.length in 4..6 && pinText == confirmPin, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Enable PIN lock") }
                    }
                    Text("PIN is stored as a SHA-256 hash in app-private preferences. Biometric unlock is not included in this version.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                FeaturePanel("HOME-SCREEN WIDGET", "Quick spending glance") {
                    Text("The existing expense widget remains enabled. Add it from your launcher: long-press the home screen → Widgets → UPI Tracker.", color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable private fun FeaturePanel(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF242329), Color(0xFF171719))), RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = Red, fontSize = 10.sp, letterSpacing = 1.3.sp)
        Text(subtitle, color = Muted, fontSize = 10.sp)
        content()
    }
}

@Composable private fun MetricCard(label: String, value: String, accent: Color, modifier: Modifier) {
    Column(modifier.background(Brush.linearGradient(listOf(Color(0xFF29272D), Color(0xFF171719))), RoundedCornerShape(16.dp)).padding(14.dp)) { Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp); Text(value, color = accent, fontSize = 19.sp) }
}

@Composable private fun EmptyState(title: String, message: String) { Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(title, color = Color.White); Text(message, color = Muted, fontSize = 11.sp) } }
private fun money(paise: Long): String = NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(paise / 100.0)
private fun dateKey(timestamp: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(timestamp))
private fun dateLabel(timestamp: Long): String = SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(Date(timestamp))
private fun dateTimeLabel(timestamp: Long): String = SimpleDateFormat("dd MMM · hh:mm a", Locale.getDefault()).format(Date(timestamp))
