package com.kamal.nothingupi.capture

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.kamal.nothingupi.data.PaymentParser
import com.kamal.nothingupi.data.TransactionRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PaymentNotificationListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName.lowercase()
        val source = when {
            pkg.contains("phonepe") -> "PhonePe"
            pkg.contains("paytm") -> "Paytm"
            pkg.contains("google") && (pkg.contains("nbu") || pkg.contains("pay")) -> "Google Pay"
            else -> return
        }
        val extras = sbn.notification.extras
        val text = listOf(
            extras.getCharSequence("android.title"),
            extras.getCharSequence("android.text"),
            extras.getCharSequence("android.bigText")
        ).filterNotNull().joinToString(" ")
        val parsed = PaymentParser.parse(text, source) ?: return
        scope.launch { TransactionRepository(applicationContext).import(parsed) }
    }
}
