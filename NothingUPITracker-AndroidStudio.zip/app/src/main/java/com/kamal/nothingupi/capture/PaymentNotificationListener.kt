package com.kamal.nothingupi.capture

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.kamal.nothingupi.data.PaymentParser
import com.kamal.nothingupi.data.TransactionRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class PaymentNotificationListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.i(TAG, "Notification listener connected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val appSource = sourceForPackage(sbn.packageName)
        val extras = sbn.notification.extras
        val pieces = mutableListOf<CharSequence?>(
            extras.getCharSequence("android.title"),
            extras.getCharSequence("android.text"),
            extras.getCharSequence("android.bigText"),
            extras.getCharSequence("android.subText"),
            sbn.notification.tickerText
        )
        extras.getCharSequenceArray("android.textLines")?.let { pieces.addAll(it) }
        val text = pieces.filterNotNull().map { it.toString().trim() }
            .filter { it.isNotEmpty() }.distinct().joinToString(" ")
        if (text.isBlank()) return
        val parsed = PaymentParser.parse(text, "NOTIFICATION: $appSource", sbn.postTime)
        if (parsed == null) {
            Log.d(TAG, "Ignored non-payment notification from $appSource")
            return
        }
        scope.launch {
            runCatching { TransactionRepository(applicationContext).import(parsed) }
                .onFailure { Log.e(TAG, "Could not save notification transaction", it) }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun sourceForPackage(packageName: String): String {
        val pkg = packageName.lowercase()
        return when {
            pkg.contains("phonepe") -> "PhonePe"
            pkg.contains("paytm") -> "Paytm"
            pkg.contains("supermoney") || pkg.contains("super.money") -> "Super.money"
            pkg == "com.google.android.apps.nbu.paisa.user" ||
                (pkg.contains("google") && (pkg.contains("nbu") || pkg.contains("paisa"))) -> "Google Pay"
            pkg.contains("bhim") || pkg.contains("npci") -> "BHIM UPI"
            pkg.contains("amazon") && (pkg.contains("shopping") || pkg.contains("pay")) -> "Amazon Pay"
            pkg.contains("cred") -> "CRED"
            pkg.contains("mobikwik") -> "MobiKwik"
            pkg.contains("freecharge") -> "Freecharge"
            pkg.contains("airtel") -> "Airtel Thanks"
            pkg.contains("whatsapp") -> "WhatsApp Pay"
            pkg.contains("navi") -> "Navi"
            pkg.contains("payzapp") -> "HDFC PayZapp"
            pkg.contains("sbi") || pkg.contains("onlinesbi") -> "SBI"
            pkg.contains("hdfc") -> "HDFC Bank"
            pkg.contains("icici") || pkg.contains("imobile") -> "ICICI Bank"
            pkg.contains("axis") -> "Axis Bank"
            pkg.contains("kotak") -> "Kotak Bank"
            pkg.contains("pnb") -> "PNB"
            pkg.contains("bob") || pkg.contains("baroda") -> "Bank of Baroda"
            pkg.contains("federal") -> "Federal Bank"
            pkg.contains("indusind") -> "IndusInd Bank"
            pkg.contains("idfc") -> "IDFC FIRST Bank"
            pkg.contains("canara") -> "Canara Bank"
            pkg.contains("unionbank") -> "Union Bank"
            // Notification listener access is user-granted. Inspect other apps too so newly
            // installed UPI/bank apps work without waiting for a package-name update. Only
            // notifications that PaymentParser recognizes as money movement are persisted.
            else -> runCatching {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 0)).toString()
            }.getOrDefault(packageName.substringAfterLast('.').ifBlank { packageName })
        }
    }

    companion object { private const val TAG = "UPITrackerListener" }
}
