package com.kamal.nothingupi.capture

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.kamal.nothingupi.data.PaymentParser
import com.kamal.nothingupi.data.TransactionRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class PaymentNotificationListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.i(TAG, "Notification listener connected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val source = sourceForPackage(sbn.packageName) ?: return
        val extras = sbn.notification.extras
        val pieces = mutableListOf<CharSequence?>(
            extras.getCharSequence("android.title"),
            extras.getCharSequence("android.text"),
            extras.getCharSequence("android.bigText"),
            extras.getCharSequence("android.subText"),
            sbn.notification.tickerText
        )
        extras.getCharSequenceArray("android.textLines")?.let { pieces.addAll(it) }
        val text = pieces.filterNotNull().map { it.toString().trim() }
            .filter { it.isNotEmpty() }.distinct().joinToString(" ")
        if (text.isBlank()) return
        val parsed = PaymentParser.parse(text, source) ?: return
        scope.launch {
            runCatching { TransactionRepository(applicationContext).import(parsed) }
                .onFailure { Log.e(TAG, "Could not save notification transaction", it) }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun sourceForPackage(packageName: String): String? {
        val pkg = packageName.lowercase()
        return when {
            pkg.contains("phonepe") -> "PhonePe"
            pkg.contains("paytm") -> "Paytm"
            pkg.contains("supermoney") || pkg.contains("super.money") -> "Super.money"
            pkg == "com.google.android.apps.nbu.paisa.user" ||
                (pkg.contains("google") && (pkg.contains("nbu") || pkg.contains("paisa"))) -> "Google Pay"
            else -> null
        }
    }

    companion object { private const val TAG = "UPITrackerListener" }
}
