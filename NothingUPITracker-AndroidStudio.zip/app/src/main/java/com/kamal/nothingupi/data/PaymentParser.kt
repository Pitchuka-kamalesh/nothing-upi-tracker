package com.kamal.nothingupi.data

import java.security.MessageDigest

data class ParsedPayment(
    val amountPaise: Long,
    val type: String,
    val merchant: String,
    val reference: String,
    val source: String,
    val raw: String
)

object CategoryRules {
    private val rules = mapOf(
        "Food & Dining" to listOf("swiggy", "zomato", "restaurant", "cafe", "pizza"),
        "Groceries" to listOf("zepto", "blinkit", "bigbasket", "dmart", "grocery"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "ajio"),
        "Transport" to listOf("uber", "ola", "rapido", "metro", "irctc"),
        "Fuel" to listOf("petrol", "fuel", "indian oil", "hpcl"),
        "Bills" to listOf("electricity", "broadband", "jio", "airtel"),
        "Healthcare" to listOf("apollo", "pharmacy", "hospital"),
        "Entertainment" to listOf("netflix", "spotify", "bookmyshow")
    )
    fun suggest(text: String): String =
        rules.entries.firstOrNull { entry -> entry.value.any { text.contains(it, true) } }?.key ?: "Other"
}

object PaymentParser {
    private val amountPattern = Regex("(?:₹|Rs\\\\.?|INR)\\\\s*([0-9,]+(?:\\\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE)
    private val refPattern = Regex("(?:UPI\\\\s*(?:Ref(?:erence)?|ID)|UTR|RRN)\\\\s*[:#-]?\\\\s*([A-Za-z0-9-]{6,})", RegexOption.IGNORE_CASE)
    private val merchantPattern = Regex("(?:to|from)\\\\s+([A-Za-z0-9 .&_-]{2,40})", RegexOption.IGNORE_CASE)

    fun parse(raw: String, source: String): ParsedPayment? {
        val text = raw.replace("\\\\n", " ").trim()
        val amount = amountPattern.find(text)?.groupValues?.get(1)
            ?.replace(",", "")?.toBigDecimalOrNull() ?: return null
        val lower = text.lowercase()
        val type = when {
            listOf("received", "credited", "credit").any(lower::contains) -> "INCOME"
            listOf("paid", "debited", "debit", "sent").any(lower::contains) -> "EXPENSE"
            else -> return null
        }
        val merchant = merchantPattern.find(text)?.groupValues?.get(1)?.trim() ?: "UPI transaction"
        return ParsedPayment(
            amountPaise = amount.movePointRight(2).toLong(),
            type = type,
            merchant = merchant,
            reference = refPattern.find(text)?.groupValues?.get(1).orEmpty(),
            source = source,
            raw = text
        )
    }
}

class TransactionRepository(context: android.content.Context) {
    private val dao = AppDatabase.get(context).transactions()
    fun observe() = dao.observeAll()
    suspend fun add(item: Transaction) = dao.insert(item)

    suspend fun import(payment: ParsedPayment): Boolean {
        val identity = payment.reference.ifBlank {
            "${payment.amountPaise}|${payment.type}|${payment.merchant.lowercase()}|${payment.raw.take(80)}"
        }
        val key = MessageDigest.getInstance("SHA-256")
            .digest(identity.toByteArray()).joinToString("") { "%02x".format(it) }
        if (dao.findByKey(key) != null) return false
        dao.insert(Transaction(
            amountPaise = payment.amountPaise,
            type = payment.type,
            merchant = payment.merchant,
            category = CategoryRules.suggest(payment.merchant + " " + payment.raw),
            source = payment.source,
            reference = payment.reference,
            importKey = key
        ))
        return true
    }
}
