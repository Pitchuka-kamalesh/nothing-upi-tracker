package com.kamal.nothingupi.data

import java.math.BigDecimal
import java.security.MessageDigest
import java.util.Locale

data class ParsedPayment(
    val amountPaise: Long,
    val type: String,
    val merchant: String,
    val reference: String,
    val source: String,
    val raw: String,
    val timestamp: Long = System.currentTimeMillis(),
    val bankName: String = "Unknown bank",
    val accountSuffix: String = ""
)

object CategoryRules {
    private val rules = mapOf(
        "Food & Dining" to listOf("swiggy", "zomato", "restaurant", "cafe", "pizza"),
        "Groceries" to listOf("zepto", "blinkit", "bigbasket", "dmart", "grocery", "vegetable", "kirana"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "ajio"),
        "Transport" to listOf("uber", "ola", "rapido", "metro", "irctc", "travel"),
        "Fuel" to listOf("petrol", "fuel", "indian oil", "hpcl"),
        "Bills" to listOf("electricity", "broadband", "jio", "airtel"),
        "Healthcare" to listOf("apollo", "pharmacy", "hospital"),
        "Entertainment" to listOf("netflix", "spotify", "bookmyshow")
    )
    fun suggest(text: String): String =
        rules.entries.firstOrNull { entry -> entry.value.any { text.contains(it, true) } }?.key ?: "Other"
}

object PaymentParser {
    private val amountPatterns = listOf(
        Regex("(?:₹|Rs\\.?|INR)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE),
        Regex("\\b([0-9,]+(?:\\.[0-9]{1,2})?)\\s*(?:INR|Rs\\.?|rupees)\\b", RegexOption.IGNORE_CASE)
    )
    private val refPattern = Regex("(?:UPI\\s*(?:Ref(?:erence)?|ID)|UTR|RRN|Txn\\s*ID)\\s*[:#-]?\\s*([A-Za-z0-9-]{6,})", RegexOption.IGNORE_CASE)
    private val merchantPattern = Regex("\\b(?:to|from|at)\\s+([A-Za-z0-9 .&_'@-]{2,60}?)(?=\\s+(?:on|via|using|UPI|Ref|Txn|ID|₹|Rs\\b|A/c|Ac\\b)|[,.;]|$)", RegexOption.IGNORE_CASE)
    private val bankNames = listOf(
        "State Bank of India" to listOf("state bank of india", "sbi"),
        "HDFC Bank" to listOf("hdfc"), "ICICI Bank" to listOf("icici"),
        "Axis Bank" to listOf("axis bank", "axisb"), "Kotak Mahindra Bank" to listOf("kotak"),
        "Punjab National Bank" to listOf("punjab national bank", "pnb"),
        "Bank of Baroda" to listOf("bank of baroda", "bob"),
        "Canara Bank" to listOf("canara"), "Union Bank of India" to listOf("union bank"),
        "Indian Bank" to listOf("indian bank"), "IDFC FIRST Bank" to listOf("idfc"),
        "Yes Bank" to listOf("yes bank"), "IndusInd Bank" to listOf("indusind"),
        "Federal Bank" to listOf("federal bank"), "AU Small Finance Bank" to listOf("au small finance", "aubank")
    )
    private val accountPattern = Regex("(?:A/C|AC|ACCOUNT|XX|ending)\\s*(?:NO\\.?\\s*)?[*Xx-]*([0-9]{3,6})", RegexOption.IGNORE_CASE)

    fun parse(raw: String, source: String, timestamp: Long = System.currentTimeMillis()): ParsedPayment? {
        val text = raw.replace("\\n", " ").replace(Regex("\\s+"), " ").trim()
        if (text.isBlank()) return null
        val amountText = amountPatterns.firstNotNullOfOrNull { it.find(text)?.groupValues?.get(1) } ?: return null
        val amount = amountText.replace(",", "").toBigDecimalOrNull() ?: return null
        val lower = text.lowercase(Locale.ROOT)
        val type = when {
            listOf("received", "credited", "credit", "deposit", "deposited", "you got", "has been credited", "deposited to", "refund received").any(lower::contains) -> "INCOME"
            listOf("paid", "debited", "debit", "withdrawn", "withdrawal", "sent", "payment to", "transferred to").any(lower::contains) -> "EXPENSE"
            else -> return null
        }
        val bank = bankNames.firstOrNull { (_, aliases) -> aliases.any { lower.contains(it) } }?.first ?: "Unknown bank"
        val account = accountPattern.find(text)?.groupValues?.get(1).orEmpty()
        val merchant = merchantPattern.find(text)?.groupValues?.get(1)?.trim()
            ?.takeIf { it.isNotBlank() } ?: when {
                lower.contains("upi") -> "UPI transfer"
                lower.contains("atm") -> "ATM transaction"
                else -> "Bank transaction"
            }
        return ParsedPayment(
            amountPaise = amount.movePointRight(2).toLong(), type = type,
            merchant = merchant, reference = refPattern.find(text)?.groupValues?.get(1).orEmpty(),
            source = source, raw = text, timestamp = timestamp,
            bankName = bank, accountSuffix = account
        )
    }
}
