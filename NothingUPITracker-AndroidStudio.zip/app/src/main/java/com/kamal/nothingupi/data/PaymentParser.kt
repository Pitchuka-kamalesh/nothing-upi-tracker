package com.kamal.nothingupi.data

import java.security.MessageDigest

data class ParsedPayment(
    val amountPaise: Long,
    val type: String,
    val merchant: String,
    val reference: String,
    val source: String,
    val raw: String,
    val timestamp: Long = System.currentTimeMillis()
)

object CategoryRules {
    private val rules = mapOf(
        "Food & Dining" to listOf("swiggy", "zomato", "restaurant", "cafe", "pizza"),
        "Groceries" to listOf("zepto", "blinkit", "bigbasket", "dmart", "grocery"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "ajio"),
        "Transport" to listOf("uber", "ola", "rapido", "metro", "irctc"),
        "Fuel" to listOf("petrol", "fuel", "indian oil", "hpcl"),
        "Bills" to listOf("electricity", "broadband", "jio", "airtel"),
        "Healthcare" to listOf("apollo", "pharmacy", "hospital"),
        "Entertainment" to listOf("netflix", "spotify", "bookmyshow")
    )
    fun suggest(text: String): String =
        rules.entries.firstOrNull { entry -> entry.value.any { text.contains(it, true) } }?.key ?: "Other"
}

object PaymentParser {
    // Kotlin string escaping: these become \\s and \\d in the Regex engine.
    private val amountPatterns = listOf(
        Regex("(?:₹|Rs\\.?|INR)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE),
        Regex("\\b([0-9,]+(?:\\.[0-9]{1,2})?)\\s*(?:INR|Rs\\.?|rupees)\\b", RegexOption.IGNORE_CASE)
    )
    private val refPattern = Regex("(?:UPI\\s*(?:Ref(?:erence)?|ID)|UTR|RRN)\\s*[:#-]?\\s*([A-Za-z0-9-]{6,})", RegexOption.IGNORE_CASE)
    private val merchantPattern = Regex("\\b(?:to|from)\\s+([A-Za-z0-9 .&_'@-]{2,60}?)(?=\\s+(?:on|via|using|UPI|Ref|Txn|ID|₹|Rs\\b)|[,.;]|$)", RegexOption.IGNORE_CASE)

    fun parse(raw: String, source: String): ParsedPayment? {
        val text = raw.replace("\\n", " ").replace(Regex("\\s+"), " ").trim()
        if (text.isBlank()) return null
        val amountText = amountPatterns.firstNotNullOfOrNull { it.find(text)?.groupValues?.get(1) } ?: return null
        val amount = amountText.replace(",", "").toBigDecimalOrNull() ?: return null
        val lower = text.lowercase()
        val type = when {
            listOf("received", "credited", "credit", "you got", "has been credited").any(lower::contains) -> "INCOME"
            listOf("paid", "debited", "debit", "sent", "payment to").any(lower::contains) -> "EXPENSE"
            else -> return null
        }
        val merchant = merchantPattern.find(text)?.groupValues?.get(1)?.trim()
            ?.takeIf { it.isNotBlank() } ?: "UPI transaction"
        return ParsedPayment(
            amountPaise = amount.movePointRight(2).toLong(),
            type = type,
            merchant = merchant,
            reference = refPattern.find(text)?.groupValues?.get(1).orEmpty(),
            source = source,
            raw = text,
            timestamp = System.currentTimeMillis()
        )
    }
}

class TransactionRepository(context: android.content.Context) {
    private val appContext = context.applicationContext
    private val dao = AppDatabase.get(appContext).transactions()
    fun observe() = dao.observeAll()
    suspend fun add(item: Transaction): Long {
        val id = dao.insert(item)
        refreshWidget()
        return id
    }
    suspend fun setCategory(id: Long, category: String) {
        dao.updateCategory(id, category)
    }
    suspend fun resetCategories() {
        dao.resetCategories()
    }
    private suspend fun refreshWidget() {
        runCatching {
            androidx.glance.appwidget.GlanceAppWidgetManager(appContext)
                .getGlanceIds(com.kamal.nothingupi.widget.ExpenseWidget::class.java)
                .forEach { com.kamal.nothingupi.widget.ExpenseWidget().update(appContext, it) }
        }
    }

    suspend fun import(payment: ParsedPayment): Boolean {
        val identity = payment.reference.ifBlank {
            "${payment.amountPaise}|${payment.type}|${payment.merchant.lowercase()}|${payment.timestamp}|${payment.raw.take(120)}"
        }
        val key = MessageDigest.getInstance("SHA-256")
            .digest(identity.toByteArray()).joinToString("") { "%02x".format(it) }
        if (dao.findByKey(key) != null) return false
        dao.insert(Transaction(
            amountPaise = payment.amountPaise,
            type = payment.type,
            merchant = payment.merchant,
            category = CategoryRules.suggest(payment.merchant + " " + payment.raw),
            source = payment.source,
            reference = payment.reference,
            timestamp = payment.timestamp,
            importKey = key
        ))
        refreshWidget()
        return true
    }
}
