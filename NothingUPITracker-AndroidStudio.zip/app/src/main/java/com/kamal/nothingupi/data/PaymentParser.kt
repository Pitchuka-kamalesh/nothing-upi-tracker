package com.kamal.nothingupi.data

import java.math.BigDecimal
import java.security.MessageDigest
import java.util.Locale

data class ParsedPayment(
    val amountPaise: Long,
    val type: String,
    val merchant: String,
    val reference: String,
    val source: String,
    val raw: String,
    val timestamp: Long = System.currentTimeMillis(),
    val bankName: String = "Unknown bank",
    val accountSuffix: String = ""
)

object CategoryRules {
    private val rules = mapOf(
        "Food & Dining" to listOf("swiggy", "zomato", "restaurant", "cafe", "pizza"),
        "Groceries" to listOf("zepto", "blinkit", "bigbasket", "dmart", "grocery", "vegetable", "kirana"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "ajio"),
        "Transport" to listOf("uber", "ola", "rapido", "metro", "irctc", "travel"),
        "Fuel" to listOf("petrol", "fuel", "indian oil", "hpcl"),
        "Bills" to listOf("electricity", "broadband", "jio", "airtel"),
        "Healthcare" to listOf("apollo", "pharmacy", "hospital"),
        "Entertainment" to listOf("netflix", "spotify", "bookmyshow")
    )
    fun suggest(text: String): String =
        rules.entries.firstOrNull { entry -> entry.value.any { text.contains(it, true) } }?.key ?: "Other"
}

object PaymentParser {
    // Extract the amount attached to the actual debit/credit verb, never the later
    // "Bal INR ..." value in bank SMS messages.
    private val money = "(?:INR|Rs\\.?|₹)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)"
    private val creditAmountPattern = Regex(
        "\\b(?:credited|credit|deposited|deposit|received)\\b(?:\\s+(?:for|with|by|of))?\\s*" + money,
        RegexOption.IGNORE_CASE
    )
    private val debitAmountPattern = Regex(
        "\\b(?:debited|debit|paid|sent|withdrawn|purchase)\\b(?:\\s+(?:for|of))?\\s*" + money,
        RegexOption.IGNORE_CASE
    )
    // Some banks put the amount before the action word: "INR 500 credited".
    private val reverseCreditPattern = Regex(
        money + "\\s*(?:has\\s+been\\s+)?(?:credited|deposited|received)\\b",
        RegexOption.IGNORE_CASE
    )
    private val reverseDebitPattern = Regex(
        money + "\\s*(?:has\\s+been\\s+)?(?:debited|withdrawn)\\b",
        RegexOption.IGNORE_CASE
    )
    private val refPattern = Regex(
        "(?:UPI\\s*(?:Ref(?:erence)?|ID)?|UTR|RRN|Txn\\s*ID)\\s*[:#-]?\\s*([A-Za-z0-9-]{6,})",
        RegexOption.IGNORE_CASE
    )
    private val merchantPattern = Regex(
        "\\b(?:to|from|by)\\s+([A-Za-z0-9 .&_'@-]{2,60}?)(?=\\s+(?:on|via|using|thru|through|UPI|Ref|Txn|ID|Bal|INR|Rs\\b|A/c|Ac\\b)|[,.;]|$)",
        RegexOption.IGNORE_CASE
    )
    private val bankNames = listOf(
        "State Bank of India" to listOf("state bank of india", "sbi"),
        "HDFC Bank" to listOf("hdfc"), "ICICI Bank" to listOf("icici"),
        "Axis Bank" to listOf("axis bank", "axisb"), "Kotak Mahindra Bank" to listOf("kotak"),
        "Punjab National Bank" to listOf("punjab national bank", "pnb"),
        "Bank of Baroda" to listOf("bank of baroda", "bob"),
        "Canara Bank" to listOf("canara"), "Union Bank of India" to listOf("union bank"),
        "Indian Bank" to listOf("indian bank"), "IDFC FIRST Bank" to listOf("idfc"),
        "Yes Bank" to listOf("yes bank"), "IndusInd Bank" to listOf("indusind"),
        "Federal Bank" to listOf("federal bank"), "AU Small Finance Bank" to listOf("au small finance", "aubank")
    )
    private val accountPattern = Regex("(?:A/C|AC|ACCOUNT|XX|ending)\\s*(?:NO\\.?\\s*)?[*Xx-]*([0-9]{3,6})", RegexOption.IGNORE_CASE)
    private val upiContextPattern = Regex("\\b(?:UPI|IMPS|NEFT|RTGS|ATM|POS|CARD|A/C|ACCT)\\b", RegexOption.IGNORE_CASE)
    private val promotionalPattern = Regex("\\b(?:offer|cashback offer|loan offer|pre-approved|apply now|click here|promo code|reward points)\\b", RegexOption.IGNORE_CASE)

    fun parse(raw: String, source: String, timestamp: Long = System.currentTimeMillis()): ParsedPayment? {
        val text = raw.replace("\\n", " ").replace(Regex("\\s+"), " ").trim()
        if (text.isBlank() || promotionalPattern.containsMatchIn(text)) return null

        val lower = text.lowercase(Locale.ROOT)
        val creditMatch = listOfNotNull(
            creditAmountPattern.find(text), reverseCreditPattern.find(text)
        ).minByOrNull { it.range.first }
        val debitMatch = listOfNotNull(
            debitAmountPattern.find(text), reverseDebitPattern.find(text)
        ).minByOrNull { it.range.first }

        // Require a transaction verb with an amount next to it. Generic words such as
        // "payment successful", "credit card offer" or a balance-only SMS are not enough.
        val selected = when {
            creditMatch == null && debitMatch == null -> return null
            creditMatch == null -> debitMatch!! to "EXPENSE"
            debitMatch == null -> creditMatch to "INCOME"
            creditMatch.range.first <= debitMatch.range.first -> creditMatch to "INCOME"
            else -> debitMatch to "EXPENSE"
        }
        val amountText = selected.first.groupValues[1].replace(",", "")
        val amount = amountText.toBigDecimalOrNull() ?: return null
        if (amount <= BigDecimal.ZERO || amount.scale() > 2) return null

        // Require a recognizable account/payment rail or transaction reference. This
        // prevents unrelated prose containing "received INR" from becoming a payment.
        val hasAccount = accountPattern.containsMatchIn(text)
        val hasPaymentContext = upiContextPattern.containsMatchIn(text) ||
            refPattern.containsMatchIn(text) || hasAccount
        if (!hasPaymentContext) return null

        val bank = bankNames.firstOrNull { (_, aliases) -> aliases.any { lower.contains(it) } }?.first
            ?: "Unknown bank"
        val account = accountPattern.find(text)?.groupValues?.get(1).orEmpty()
        val merchant = merchantPattern.find(text)?.groupValues?.get(1)?.trim()
            ?.takeIf { it.isNotBlank() } ?: when {
                lower.contains("upi") -> "UPI transfer"
                lower.contains("atm") -> "ATM transaction"
                else -> "Bank transaction"
            }
        val reference = refPattern.find(text)?.groupValues?.get(1).orEmpty()
        return ParsedPayment(
            amountPaise = amount.movePointRight(2).longValueExact(),
            type = selected.second,
            merchant = merchant,
            reference = reference,
            source = source,
            raw = text,
            timestamp = timestamp,
            bankName = bank,
            accountSuffix = account
        )
    }
}
