# DotLedger Privacy Policy — publication template

**Last updated:** [DATE]

**Developer/operator:** [LEGAL NAME OR ORGANISATION]  
**Contact:** [SUPPORT EMAIL]  
**App:** DotLedger (package: `com.kamal.nothingupi`)

> Replace every bracketed placeholder and verify this document against the exact release before publishing it. Do not submit a placeholder policy to Google Play.

## Data processed on your device

DotLedger is designed as a local-first personal finance tracker. Transaction records, categories, comments, bank balance snapshots, budgets and app preferences are stored in the app's private storage on your device.

## Files you choose to import

You may explicitly select SMS text exports or bank CSV files using Android's system document picker. DotLedger reads the file you select to identify supported payment records. DotLedger does not request permission to scan your SMS inbox in this release. You can remove imported records inside the app. Removing a record from DotLedger does not delete the source file or any SMS in your messaging app.

## Optional notification access

If you choose to enable Android notification access, DotLedger inspects notifications from supported payment and banking apps to identify payment amounts, direction, references and timestamps. Only notifications recognized as payment transactions are saved to the local transaction database. Unrelated app notifications are ignored and not stored. You can revoke notification access at any time in Android Settings.

## Sharing and transmission

[Confirm whether the release has any network functionality. If no data is transmitted, state this only after verifying the final merged manifest and all dependencies. If any analytics, crash reporting, ads or network services are added, describe them here.]

## Retention and deletion

Transaction data remains in the app's private storage until you delete records or uninstall the app. CSV exports and JSON backups are created only when you request them and choose a destination. Keep exported files secure. [Describe any backup/restore implementation accurately.]

## Security

DotLedger uses Android app-private storage. [Describe database encryption, authentication and device security accurately; do not claim encryption unless implemented and tested.] No application can guarantee absolute security. Keep your device updated and protect exported files.

## Children's privacy

[Insert the operator's age policy and applicable child privacy practices.]

## Changes and contact

We may update this policy when app functionality changes. For questions or privacy requests, contact [SUPPORT EMAIL].
